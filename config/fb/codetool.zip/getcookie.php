<?php
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';

$_SESSION["token"]="d535915862f77b41d8996891f3251749";
echo logintoken();
function logintoken(){
    $data = 'access_token='.$_SESSION['token'];
    $head[] = 'Content-type: application/x-www-form-urlencoded';
$ch   = curl_init();
curl_setopt_array($ch, array(
    CURLOPT_URL => 'https://vipig.net/logintoken.php',
    CURLOPT_FOLLOWLOCATION => TRUE,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_HTTPHEADER => $head,
    CURLOPT_COOKIEJAR => "VIPIG.txt",
    CURLOPT_COOKIEFILE => "VIPIG.txt",
    CURLOPT_USERAGENT => $_SESSION['useragent'],
    CURLOPT_ENCODING => TRUE
));
echo curl_exec($ch);
$login = json_decode(curl_exec($ch));
if($login->status == 'success'){
        $xu = $login->data->sodu;
        $_SESSION['user'] = $login->data->user;
        $_SESSION['sodu'] = $login->data->sodu;
        $js = fopen($_SESSION['user'].".txt", "a+");
        ///$js = fopen("VIPIG.txt", "a+");
        //file_put_contents($_SESSION['user'].".txt", file_get_contents("VIPIG.txt"));
        ///unlink("VIPIG.txt");
        return true;
} else if($login->status == 'fail'){
    echo "\033[1;31m ".$login->mess."\n";
    sleep(1);
    return false;
} else {
    echo "\033[1;31m Kiểm Tra VPN (không đc sử dụng ip nước ngoài)\n";
        return false;
}
}
echo $_SESSION['user']."\n";
echo $_SESSION['sodu']."\n";