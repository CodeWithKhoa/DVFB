<?php

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.facebook.com/api/graphql/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: www.facebook.com',
    'accept: */*',
    'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'content-type: application/x-www-form-urlencoded',
    'origin: https://www.facebook.com',
    'referer: https://www.facebook.com/100063480104642/reviews/',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: empty',
    'sec-fetch-mode: cors',
    'sec-fetch-site: same-origin',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 724',
    'x-asbd-id: 129477',
    'x-fb-friendly-name: ComposerStoryCreateMutation',
    'x-fb-lsd: tqrSgt8XRggqxy_KIM68Po',
]);
curl_setopt($ch, CURLOPT_COOKIE, 'sb=UdeqZIJ4wX07a4Bx3yVNcZEV; dpr=1.25; datr=uuarZHU-ArFyE745VvVNyTFD; c_user=100094229006180; i_user=100094634736968; m_page_voice=100094634736968; usida=eyJ2ZXIiOjEsImlkIjoiQXJ4bDFsNjFub3A2YWsiLCJ0aW1lIjoxNjg4OTk1OTE0fQ%3D%3D; xs=21%3A337LCmZ9ZlXu6Q%3A2%3A1688987325%3A-1%3A-1%3A%3AAcXD1Yxu-PL0Djyz7ylyFCjXcMjy9poKRkA6qWaHHDY; fr=0KbZ03GwGraS1Ppm1.AWXDIPssmxqqeCDM0i74Q6-3hvc.BkrA4r.vY.AAA.0.0.BkrA4r.AWXXpsNHUFA; wd=724x746');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'av=100094634736968&__user=100094634736968&__a=1&__req=y&__hs=19548.HYP%3Acomet_pkg.2.1..2.1&dpr=1.5&__ccg=EXCELLENT&__rev=1007811254&__s=kfube6%3A7knzsj%3Awbrlvh&__hsi=7254189946126118691&__dyn=7AzHxqUW13xt0mUyEqxenFwLBwopU98nwgUao4u5QdwSxucyUco5S3O2Saw8i2S1DwUx609vCxS320om78bbwto88422y11xmfz83WwgEcEhwGxu782lwv89kbxS2218wc61axe3S7Udo5qfK0zEkxe2GewyDwkUtxGm2SUbElxm3y3aexfxmu3W3y1MBx_y88E3qxWm2Sq2-azqwt8eo88cA0z8c84q58jwTwNxe6Uak1xwJwxyo566k1Fw&__csr=gbf2tTfb4lsRZOjjjlf5jn4Pvird9cJbath3RtXsNCKHECAJuJeiQjv8Ju_J95Hy4FmRDiGiWt294RWrF6z96ucJ5y8CqaCxa8Ax54J5AGZp4LUxqACh9qiCCGurCjAhWh9Uk_h8mzrGexN1W8Gip2uuqZ2umi8Vku5oWbwPAjUuDzXyp9KbhkcDwzy8hBz8B4AzEy2CiXK6olGFoKcxa64ui16gerG6UjwLxaq2-78y2qfhE4iuEKdxC6EK2m3e8w-xu8wq88UqzosyUS1fxGmjwXxW6V88ovzU02qAg07J2037K0i20Ho28DgGhw5Uw6nw58G09Jw_waC49UcFA0HFU2kwtof43G0v100AMEE19u07jo0Gfxq1eg3NwEwed02zE0Y8w1x8pg1M8qxfCkw0-W0geu06upU0kfw77w7P80sEhhmawoQp09-0ii0tZ0dS0dAwo89o9E&__comet_req=15&fb_dtsg=NAcMN_qpfnUo-yixL6c23VYOZJXtNaNAnW2CqhR6FPv7RUilUkVYmUw%3A21%3A1688987325&jazoest=25588&lsd=tqrSgt8XRggqxy_KIM68Po&__spin_r=1007811254&__spin_b=trunk&__spin_t=1688997714&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=ComposerStoryCreateMutation&variables=%7B%22input%22%3A%7B%22composer_entry_point%22%3A%22inline_composer%22%2C%22composer_source_surface%22%3A%22page_recommendation_tab%22%2C%22idempotence_token%22%3A%22cdda441b-291c-4073-a7d0-5fc378dd01b957_FEED%22%2C%22source%22%3A%22WWW%22%2C%22audience%22%3A%7B%22privacy%22%3A%7B%22allow%22%3A%5B%5D%2C%22base_state%22%3A%22EVERYONE%22%2C%22deny%22%3A%5B%5D%2C%22tag_expansion_state%22%3A%22UNSPECIFIED%22%7D%7D%2C%22message%22%3A%7B%22ranges%22%3A%5B%5D%2C%22text%22%3A%22Nh%C3%A2n%20vi%C3%AAn%20ni%E1%BB%81m%20n%E1%BB%9F%2C%20chuy%C3%AAn%20nghi%E1%BB%87p%2C%20th%C3%A2n%20thi%E1%BB%87n%20v%C3%A0%20lu%C3%B4n%20s%E1%BA%B5n%20l%C3%B2ng%20h%E1%BB%97%20tr%E1%BB%A3%20kh%C3%A1ch%20h%C3%A0ng.%22%7D%2C%22with_tags_ids%22%3A%5B%5D%2C%22text_format_preset_id%22%3A%220%22%2C%22page_recommendation%22%3A%7B%22page_id%22%3A%221333161980165804%22%2C%22rec_type%22%3A%22POSITIVE%22%7D%2C%22logging%22%3A%7B%22composer_session_id%22%3A%22cdda441b-291c-4073-a7d0-5fc2cd01b957%22%7D%2C%22navigation_data%22%3A%7B%22attribution_id_v2%22%3A%22ProfileCometReviewsTabRoot.react%2Ccomet.profile.reviews%2Cvia_cold_start%2C1688997714932%2C939769%2C250100865708545%2C%22%7D%2C%22tracking%22%3A%5Bnull%5D%2C%22actor_id%22%3A%22100094634736968%22%2C%22client_mutation_id%22%3A%221%22%7D%2C%22displayCommentsFeedbackContext%22%3Anull%2C%22displayCommentsContextEnableComment%22%3Anull%2C%22displayCommentsContextIsAdPreview%22%3Anull%2C%22displayCommentsContextIsAggregatedShare%22%3Anull%2C%22displayCommentsContextIsStorySet%22%3Anull%2C%22feedLocation%22%3A%22PAGE_SURFACE_RECOMMENDATIONS%22%2C%22feedbackSource%22%3A0%2C%22focusCommentID%22%3Anull%2C%22gridMediaWidth%22%3Anull%2C%22groupID%22%3Anull%2C%22scale%22%3A1.5%2C%22privacySelectorRenderLocation%22%3A%22COMET_STREAM%22%2C%22renderLocation%22%3A%22timeline%22%2C%22useDefaultActor%22%3Afalse%2C%22inviteShortLinkKey%22%3Anull%2C%22isFeed%22%3Afalse%2C%22isFundraiser%22%3Afalse%2C%22isFunFactPost%22%3Afalse%2C%22isGroup%22%3Afalse%2C%22isEvent%22%3Afalse%2C%22isTimeline%22%3Atrue%2C%22isSocialLearning%22%3Afalse%2C%22isPageNewsFeed%22%3Afalse%2C%22isProfileReviews%22%3Atrue%2C%22isWorkSharedDraft%22%3Afalse%2C%22UFI2CommentsProvider_commentsKey%22%3A%22ProfileCometReviewsTabRoute%22%2C%22hashtag%22%3Anull%2C%22canUserManageOffers%22%3Afalse%2C%22__relay_internal__pv__IsWorkUserrelayprovider%22%3Afalse%2C%22__relay_internal__pv__IsMergQAPollsrelayprovider%22%3Afalse%2C%22__relay_internal__pv__StoriesArmadilloReplyEnabledrelayprovider%22%3Afalse%2C%22__relay_internal__pv__StoriesRingrelayprovider%22%3Afalse%7D&server_timestamps=true&doc_id=9498364856901001');

$response = curl_exec($ch);

curl_close($ch);
echo $response;