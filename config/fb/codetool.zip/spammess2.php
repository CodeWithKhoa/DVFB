<?php 
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$cyan= "\e[1;36m";
$thanhngang = $vang."-------------------------------------------------------------\n";
/***[ Time ]***/
$today= date('d-m-y');
$a = date("d"); 
$b = date("m"); 
$c = date("Y");
$ngay = date("d"); 
$thang = date("m"); 
$nam = date("Y");
$day= date('d-m-y');
$d = date("d-m");
$weekday = date("l");
$fileck="cookiespam.txt";
if(file_exists($fileck)){
    echo $luc."Bạn đã lưu cookie từ trước, nhập Y để vào tool: ";
    $nhap=trim(fgets(STDIN));
    if($nhap=='y'){
        $cookie=file_get_contents($fileck);
    } else if($nhap=="Y"){
        $cookie=file_get_contents($fileck);
    } else {
        unlink($fileck);
    }
}
if(!file_exists($fileck)){
    echo $luc."Nhập Cookie: ";
    $cookie=trim(fgets(STDIN));
    file_put_contents($fileck,$cookie);
}
echo $luc."Nhập id TCN hoặc id Box: ";
$idspam=trim(fgets(STDIN));
$stt=0;
$listnoidung=[];
while(true){
    $stt++;
    echo $luc."Nhập nội dung thứ $stt: ";
    $noidung=readline();
    if($noidung==''){
        break;
    }
    array_push($listnoidung,$noidung);
}
echo $luc."Nhập delay: ";
$delay=trim(fgets(STDIN));
@system('clear');
$stt=0;
while(true){
    for($i=0;$i<count($listnoidung);$i++){
        $stt++;
        while (!checkInternetConnection()) {
            echo $do."\rKhông có kết nối Internet.\r";
            sleep(1);
        }
        $spam=spamib($idspam,$listnoidung[$i],$cookie);
        if($spam=='success'){
            echo $vang."[".$trang.$stt.$vang."]".$luc." Spam Thành Công$trang | ".$vang.$idspam.$trang." | \n";
            delay($delay);
        }
    }

}


/*********[*FUNCTION*]*********/
function checkInternetConnection() {
    $headers = @get_headers('https://www.example.com');

    if ($headers && strpos($headers[0], '200') !== false) {
        return true; // Có kết nối Internet
    } else {
        return false; // Không có kết nối Internet
    }
}
function spamib($idsp,$nd,$cookie){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/messages/read/?tid='.$idsp);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'authority: mbasic.facebook.com',
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'cache-control: max-age=0',
        'sec-ch-prefers-color-scheme: light',
        'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.134", "Google Chrome";v="114.0.5735.134"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'sec-ch-ua-platform-version: "15.0.0"',
        'sec-fetch-dest: document',
        'sec-fetch-mode: navigate',
        'sec-fetch-site: same-origin',
        'sec-fetch-user: ?1',
        'upgrade-insecure-requests: 1',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'viewport-width: 987',
    ]);
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    $response = curl_exec($ch);
    if(strpos($response,'messages/send/?')!==false){
        $url='https://mbasic.facebook.com/messages/send/?'.str_replace('amp;','',explode('"',explode('/messages/send/?',$response)[1])[0]);
        $fb_dtsg=explode('"',explode('fb_dtsg" value="',$response)[1])[0];
        $jazoest=explode('"',explode('jazoest" value="',$response)[1])[0];
        $send='Gửi';
        if(strpos($response,'tids" value="')!==false){
        $tids=explode('"',explode('tids" value="',$response)[1])[0];
        $wwwupp=explode('"',explode('wwwupp" value="',$response)[1])[0];
        $platform_xmd=explode('"',explode('platform_xmd" value="',$response)[1])[0];
        $cver=explode('"',explode('cver" value="',$response)[1])[0];
        $csid=explode('"',explode('csid" value="',$response)[1])[0];
        } else {
            $tids="";
            $wwwupp='';
            $platform_xmd='';
            $cver='';
            $csid='';
        }
        $data='fb_dtsg='.$fb_dtsg.'&jazoest='.$jazoest.'&body='.urlencode($nd).'&send='.$send.'&tids='.$tids.'&wwwupp='.$wwwupp.'&platform_xmd='.$platform_xmd.'&referrer=&ctype=&cver='.$cver.'&csid='.$csid;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'authority: mbasic.facebook.com',
            'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'cache-control: max-age=0',
            'content-type: application/x-www-form-urlencoded',
            'origin: https://mbasic.facebook.com',
            'sec-ch-prefers-color-scheme: light',
            'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
            'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.134", "Google Chrome";v="114.0.5735.134"',
            'sec-ch-ua-mobile: ?0',
            'sec-ch-ua-platform: "Windows"',
            'sec-ch-ua-platform-version: "15.0.0"',
            'sec-fetch-dest: document',
            'sec-fetch-mode: navigate',
            'sec-fetch-site: same-origin',
            'sec-fetch-user: ?1',
            'upgrade-insecure-requests: 1',
            'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
            'viewport-width: 987',
        ]);
        curl_setopt($ch, CURLOPT_COOKIE, $cookie);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $response = curl_exec($ch);
        curl_close($ch);
        return'success';
    } else {
        return 'error';
    }
}
function delay($delay)
{
    for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;33m   Vui Lòng Chờ \033[1;31m =>       \033[1;32m LO      \033[1;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;31m    Vui Lòng Chờ \033[0;33m   =>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;32m    Vui Lòng Chờ \033[0;33m    =>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;34m    Vui Lòng Chờ \033[0;33m     => \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;35m    Vui Lòng Chờ \033[0;33m      =>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;35m    Vui Lòng Chờ \033[0;33m       =>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(1);
        echo "\r\033[1;35m    Vui Lòng Chờ \033[0;33m        =>\033[0;37m LOADING\033[0;31m | $tt | ";
        usleep(1);
        echo "\r\e[1;95m    Vui Lòng Chờ                                  \r";
    }
}