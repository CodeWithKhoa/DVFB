<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://business.facebook.com/business_locations/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: business.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: none',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 892',
]);
curl_setopt($ch, CURLOPT_COOKIE, 'sb=IgJKZGIwX9dMhVwVEo2tyugT; datr=JwJKZJPR6bkgBQvPkCtxps7V; c_user=100091272480232; m_page_voice=100091272480232; cppo=1; locale=vi_VN; xs=15%3A9p5SMIi15n3J-g%3A2%3A1682929397%3A-1%3A6279%3A%3AAcW3y4nZZSPGuQnW07FXV40qz8beAKSl79-JkN0MxpI; fr=0TkiRXDAHuluSI7MU.AWXNpFcPHuzZbNxZN1c2nlFbRjY.Bkp5Gg.mZ.AAA.0.0.Bkp5Gg.AWWDWteQ2R0; presence=EDvF3EtimeF1688703402EuserFA21B91272480232A2EstateFDutF0CEchF_7bCC; usida=eyJ2ZXIiOjEsImlkIjoiQXJ4ZXJ5Yms2enlpYSIsInRpbWUiOjE2ODg3MDM0OTF9; wd=892x678; dpr=1.375');

$response = curl_exec($ch);
curl_close($ch);
echo $response;