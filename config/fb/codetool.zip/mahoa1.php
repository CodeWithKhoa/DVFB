<?php
// Khóa mã hóa chung (master key)
$masterKey = "TOOLTDKCHAOCACBAN";

// Khóa AES-256-CBC cần được mã hóa
$aesKey = str_replace(array("\n", "\r"),'',explode('<?php',file_get_contents('5.0.php'))[1]);

// Tạo vectơ khởi tạo (IV) ngẫu nhiên
$iv = openssl_random_pseudo_bytes(16);

// Mã hóa khóa AES-256-CBC bằng master key
$ciphertext = openssl_encrypt($aesKey, 'AES-128-CTR', $masterKey, 0, '3112200612110688');echo $ciphertext;
file_put_contents('enc5.0.php',"<?php eval(openssl_decrypt('".$ciphertext."', 'AES-128-CTR', 'TOOLTDKCHAOCACBAN', 0, '3112200612110688'));");

?>
