<?php

@system('clear');
error_reporting(0);
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$whiteb="\033[1;37m";
$red="\033[0;31m";
$redb="\033[1;31m";
/***[ Đánh Dấu Bản Quyền ]***/
$dp_tool = $trang."".$do."[".$do ."🔥".$do."] ".$trang."=> ";
$ndp = $trang."".$do."[".$do."🔥".$do."] ";
/***[ Delay ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    $_SESSION['load'] = 1200;
    $_SESSION['delay'] = 2000;
} else {
    $_SESSION['load'] = 0;
    $_SESSION['delay'] = 1000;
}
/***[ Config ]***/
$_SESSION['version'] = "9.5";
$_SESSION['shop'] = "Shopducphat.com";
/***[ Banner ]***/
$banner = "
\033[1;33m█████\033[1;31m╗  \033[1;33m███\033[1;31m╗   \033[1;33m██\033[1;31m╗     \033[1;33m██████\033[1;31m╗ \033[1;33m██████\033[1;31m╗ \033[1;33m██\033[1;31m╗\033[1;33m███\033[1;31m╗   \033[1;33m██\033[1;31m╗\033[1;37m
\033[1;33m██\033[1;31m╔══\033[1;33m██\033[1;31m╗\033[1;33m████\033[1;31m╗  \033[1;33m██\033[1;31m║    \033[1;33m██\033[1;31m╔═══\033[1;33m██\033[1;31m╗\033[1;33m██\033[1;31m╔══\033[1;33m██\033[1;31m╗\033[1;33m██\033[1;31m║\033[1;33m████\033[1;31m╗  \033[1;33m██\033[1;31m║
\033[1;33m███████\033[1;31m║\033[1;33m██\033[1;31m╔\033[1;33m██\033[1;31m╗ \033[1;33m██\033[1;31m║    \033[1;33m██\033[1;31m║   \033[1;33m██\033[1;31m║\033[1;33m██████\033[1;31m╔╝\033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m╔\033[1;33m██\033[1;31m╗ \033[1;33m██\033[1;31m║ 
\033[1;33m██\033[1;31m╔══\033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m║\033[1;31m╚\033[1;33m██\033[1;31m╗\033[1;33m██\033[1;31m║    \033[1;33m██\033[1;31m║   \033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m╔══\033[1;33m██\033[1;31m╗\033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m║\033[1;31m╚\033[1;33m██\033[1;31m╗\033[1;33m██\033[1;31m║
\033[1;33m██\033[1;31m║  \033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m║ \033[1;31m╚\033[1;31m\033[1;33m████\033[1;31m║    \033[1;31m╚\033[1;31m\033[1;33m██████\033[1;31m╔╝\033[1;33m██\033[1;31m║  \033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m║\033[1;33m██\033[1;31m║ \033[1;31m╚\033[1;31m\033[1;33m████\033[1;31m║ 
\033[1;31m╚═╝  ╚═╝╚═╝  ╚═══╝     ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ 
\033[1;32m════════════════════════════════════════════════════════
\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;32mAdmin:\033[1;35m An Orin
\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;36mGroup Zalo:\033[1;37m https://zalo.me/g/dpfbxq529
\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;36mBản quyền Của \033[1;37m: An Orin
\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;33mTool Spam comment 1 ID
\033[1;32m════════════════════════════════════════════════════════
";
/***[ Clear + Thông Số Admin ]***/
cmt1id($banner, $dp_tool );
$khoToken = [];
if (file_exists('TokenSpamComment.txt')) {
    echo $dp_tool.$luc."Nhập ".$do."[".$vang."1".$do."] ".$luc."Thêm Token Facebook Để Chạy\n";
    echo $dp_tool.$luc."Nhập ".$do."[".$vang."2".$do."] ".$luc."Vào Chạy Tool Vì Lần Trước Lưu Token Facebook Rồi\n";
    echo "\e[1;37m".str_repeat('= ', 35)."\n";
    echo $dp_tool.$luc."Vui Lòng Nhập Lựa Chọn".$trang.":".$vang." ";
       $choice = trim(fgets(STDIN));
    echo "\e[1;37m".str_repeat('= ', 35)."\n";
       if ($choice == "1") {
         @system('rm TokenSpamComment.txt');
       }else if ($choice == "2") {
         $NhapToken = file_get_contents('TokenSpamComment.txt');
       }else {
         exit("\033[1;91m[ERROR] \033[1;97m=> \033[1;91mLỗi Không Xác Định.\n");
       }
}
if (!file_exists('TokenSpamComment.txt')) {
  echo $dp_tool.$luc."Bạn Muốn Chạy Bao Nhiêu Token Facebook".$trang.":".$vang." ";
  $sltk = trim(fgets(STDIN));
  echo"\033[1;32m════════════════════════════════════════════════════════\n";
  for($a=1;$a<=$sltk;$a++){
    echo"\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;32mLink Lấy Token ".$trang."Facebook: ".$vang."https://bom.so/SJrFLd\n";
    echo"\033[1;32m════════════════════════════════════════════════════════\n";
    echo $dp_tool.$luc."Vui Lòng Nhập Token Facebook Thứ ".$trang.$a.$trang.": \033[1;33m";
    $NhapToken = (string)trim(fgets(STDIN));
    if($NhapToken == ""){
      break;
    }
    array_push($khoToken, $NhapToken);
  }
  $js = json_encode($khoToken);
  $DemToken = count($khoToken);
       $k = fopen("TokenSpamComment.txt", "a+");
  fwrite($k, $js);
  fclose($k);
  echo "\033[1;93m[\033[1;97mSAVE\033[1;93m] \033[1;97m=> \033[1;92mĐã Lưu \033[1;93m$DemToken \033[1;92mToken Facebook Vào File \033[1;97mTokenSpamComment.txt\n";
  sleep(2);
}else{
  $khoToken = json_decode(fread(fopen("TokenSpamComment.txt","r"), filesize("TokenSpamComment.txt")), TRUE);
  $DemToken = count($khoToken);
}
@system('clear');
cmt1id($banner, $dp_tool );
echo $dp_tool.$luc."\033[1;92mNhập Link Bài Viết Cần Spam Comment: \033[1;97m";
$Link = trim(fgets(STDIN));
$GetLink = "\033[1;93mĐang GET ID Từ Link Bài Viết...";
$RunGetLink = strlen($GetLink);
for ($x = 0;$x < $RunGetLink; $x++) {
  echo $GetLink[$x];
  usleep(5000);
}
$DataLink = GetUID($Link);
echo "\r";
if (strpos($DataLink, 'error') != FALSE) {
  $DecodeJS = json_decode($DataLink, TRUE);
  $LinkError = $DecodeJS['error'];
  if ($LinkError == "Link không tồn tại hoặc chưa để chế độ công khai!"){
    $LinkError = "Link Không Tồn Tại Hoặc Không Để Chế Độ Công Khai.";
  }else if ($LinkError == "Vui lòng nhập đúng link facebook") {
    $LinkError = "Vui Lòng Nhập Đúng Link Facebook.";
  }else if ($LinkError == "Thiếu dữ liệu đầu vào!") {
    $LinkError = "Vui Lòng Không Được Bỏ Trống.";
  }else if ($LinkError == "Vui lòng thử lại!") {
    $LinkError = "Vui Lòng Thử Lấy Lại Link.";
  }
  echo "\033[1;91m[ERROR] \033[1;97m=> \033[1;91m$LinkError\n";
  exit;
}
$UII = explode('id":', $DataLink)[1];
$UIDD = explode(',', $UII)[0];
$EX = substr($UIDD, 0, 1);
$Dau = '"';
if ($EX == $Dau) {
  $UI = explode('id":"', $DataLink)[1];
  $UID = explode('",', $UI)[0];
}else{
  $UI = explode('id":', $DataLink)[1];
  $UID = explode(',', $UI)[0];
}
$CheckUID = intval($UID);
if ($CheckUID == "0") {
  echo "\033[1;91m[ERROR] \033[1;97m=> \033[1;91mGET ID Bài Viết Lỗi.\n";
  echo $dp_tool.$luc."Lấy ID Tại: \033[1;93mhttps://id.traodoisub.com\n";
  echo $dp_tool.$luc."Nhập ID Bài Viết Hoặc Ảnh: \033[1;97m";
  $UID = trim(fgets(STDIN));
}else{
  $succuid = $dp_tool.$luc."ID Bài Viết Của Bạn Là: \033[1;93m$UID\n";
  echo "\e[1;37m".str_repeat('= ', 35)."\n";
  $runsuccuid = strlen($succuid);
  for ($x = 0; $x < $runsuccuid; $x++) {
    echo $succuid[$x];
    usleep(5000);
  }
}
echo $dp_tool.$luc."\033[1;92mNhập Nội Dung Spam Comment: \033[1;97m";
$msg = trim(fgets(STDIN));
echo $dp_tool.$luc."\033[1;92mNhập Thời Gian Để Spam Comment: \033[1;97m";
$delay = trim(fgets(STDIN));
if ($DemToken >= 2) {
  echo $dp_tool.$luc."Spam Comment Bao Nhiêu Lần Thì Đổi Token Khác: \033[1;97m";
  $doinick = trim(fgets(STDIN));
}else{
  $doinick = "99999";
}
echo $dp_tool.$luc."Dừng Tools Sau Bao Nhiêu Lần Spam Comment: \033[1;97m";
$dungtool = trim(fgets(STDIN));
@system('clear');
cmt1id($banner, $dp_tool );
while (true){
  for ($xz =0 ; $xz < count($khoToken); $xz++) {
    if(count($khoToken) == 0){
        echo $dp_tool.$luc."Bạn Muốn Chạy Bao Nhiêu Token Facebook\033[1;97m: \033[1;97m";
        $sltk = trim(fgets(STDIN));
        echo "\e[1;37m".str_repeat('= ', 35)."\n";
        for($a=1;$a<=$sltk;$a++){
        echo $dp_tool.$luc."Link HD Lấy Token ".$trang."EAAB: ".$vang."https://tanglike.biz/laytokenF12.html\n";
        echo $dp_tool.$luc."Nhập Token Facebook Thứ ".$trang.$a.$trang.": \033[1;97m";
        $NhapToken = trim(fgets(STDIN));
        if($NhapToken == ""){
          break;
        }
        array_push($khoToken, $NhapToken);
      }
      $js = json_encode($khoToken);
      $DemToken=count($khoToken);
      $k = fopen("TokenSpamComment.txt", "a+");
      fwrite($k, $js);
      fclose($k);
      echo "\033[1;93m[\033[1;97mSAVE\033[1;93m] \033[1;97m➩ \033[1;92mĐã Lưu \033[1;93m$DemToken \033[1;92mToken Facebook Vào File \033[1;97mTokenSpamComment.txt\n";
      sleep(2);
    }
    for($xz = 0; $xz < count($khoToken); $xz++){
      $cookie = $khoToken[$xz];
      $access_token = $cookie;
      if(strpos($access_token, 'EAA') !== 0){
        echo "\033[1;91m[ERROR] \033[1;97m➩ \033[1;91mToken Sai Định Dạng.\n";
      }
      $tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'name'};
      $id_fb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token='.$access_token))-> {'id'};
      $spam = 0;
      while(true){
        if ($spam == 1){
          break;
        }
        if ($tenfb == "") {
          echo "\033[1;91m[ERROR] \033[1;97m➩ \033[1;91mToken Die.\n";
          array_splice($KhoToken, $xz, 1);
          $spam = 1;
          break;
        }
        else {
        	echo $vang."==========================================================\n";
                    echo $vang."Đang Cấu Hình ID: ".$luc.$id_fb." ".$vang."Tên FB: ".$luc.$tenfb."\n";
                    echo $vang."==========================================================\n";
        }
        while(true){
          cmt($access_token, $UID, $cookie, $msg);
          $dem ++;
          $today = date("H:i:s");
          $type = "COMMENT THÀNH CÔNG";
          $hoanthanh = "\033[1;31m[\033[1;33m$dem\033[1;31m]\033[1;31m | \033[1;36m$today\033[1;31m | \033[1;33m$type\033[1;31m | \033[1;97m$UID \033[1;31m| \033[1;97m$msg \n";
          $chayhoanthanh = strlen($hoanthanh);
          for ($x = 0; $x < $chayhoanthanh; $x++) {
            echo $hoanthanh[$x];
            usleep(5000);
          }
          if($dem >= $dungtool){
            echo "\e[1;37m".str_repeat('= ', 35)."\n";
            echo'\033[1;31m[🔥\033[1;31m] \033[1;37m=> \033[1;32mĐã Hoàn Thành \033[1;97m$dem\033[1;92m Nhiệm Vụ!\n\033[1;37m~\033[1;37m[\033[1;31m-_-\033[1;37m] \033[1;37m➩ \033[1;92mBạn Có Muốn Tiếp Tục Chạy Nữa Không \033[1;97m[\033[1;93mY\033[1;97m/\033[1;93mN\033[1;97m]: $trang"';
            $tuychon = trim(fgets(STDIN));
            if($tuychon == "N" || $tuychon == "n"){
              exit;
            }else if($tuychon == "Y" || $tuychon == "y"){
              echo $dp_tool.$luc."Bạn Muốn Chạy Thêm Bao Nhiêu Nhiệm Vụ Nữa: $trang";
              $chaythem = trim(fgets(STDIN));
              echo "\e[1;37m".str_repeat('= ', 35)."\n";
              $dungtool = $dungtool + $chaythem;
            }else{
              exit("\033[1;91m[ERROR] \033[1;97m➩ \033[1;91mLỗi Không Xác Định. \n");
            }
          }
          if($dem % $doinick == 0){
            $spam = 1;
            break;
          }
          delay($delay);
        }
      }
    }
  }
}
function cmt($access_token, $UID, $cookie, $msg){
  /* Copyright © 2021 - 2022 : Nguyễn Đức Phát */
  $ch=curl_init();
  curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
  curl_setopt($ch, CURLOPT_TCP_FASTOPEN, true);
       curl_setopt($ch, CURLOPT_URL, 'https://graph.facebook.com/'.$UID.'/comments');
       $head[] = "Connection: keep-alive";
       $head[] = "Keep-Alive: 300";
       $head[] = "authority: m.facebook.com";
       $head[] = "ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
       $head[] = "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5";
       $head[] = "cache-control: max-age=0";
       $head[] = "upgrade-insecure-requests: 1";
       $head[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
       $head[] = "sec-fetch-site: none";
       $head[] = "sec-fetch-mode: navigate";
       $head[] = "sec-fetch-user: ?1";
       $head[] = "sec-fetch-dest: document";
       curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36');
       curl_setopt($ch, CURLOPT_ENCODING, '');
       curl_setopt($ch, CURLOPT_COOKIE, $cookie);
       curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
       curl_setopt($ch, CURLOPT_TIMEOUT, 60);
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
       curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
       $data = array('message' => $msg ,'access_token' => $access_token);
       curl_setopt($ch, CURLOPT_POST, count($data));
       curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
       $access = curl_exec($ch);
    curl_close($ch);
    return json_decode($access);
}
function GetUID($Link) {
  $ch = curl_init('https://id.traodoisub.com/api.php');
  $data= ('link=').$Link;
  $head[] = "Host:id.traodoisub.com";
  $head[] = "user-agent:Mozilla/5.0 (Linux; Android 10; CPH1933) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36";
  $head[] = "content-type:application/x-www-form-urlencoded; charset=UTF-8";
  curl_setopt($ch, CURLOPT_PORT, "443");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}
function delay($delay)
{
    for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;33m   Trần Đăng Khoa \033[1;31m =>       \033[1;32m LO      \033[1;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;31m    Trần Đăng Khoa \033[0;33m   =>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;32m    Trần Đăng Khoa \033[0;33m    =>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;34m    Trần Đăng Khoa \033[0;33m     => \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m      =>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(140000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m       =>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m        =>\033[0;37m LOADING\033[0;31m | $tt | ";
        usleep(14500);
        echo "\r\e[1;95m    Trần Đăng Khoa                                  \r";
    }
}
function cmt1id($banner, $dp_tool ){
    for($i = 0; $i < strlen($banner); $i++){echo $banner[$i];usleep($_SESSION['load']);}
}