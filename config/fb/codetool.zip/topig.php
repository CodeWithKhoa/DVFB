<?php
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$_SESSION["C_LIKE"]   = " LIKE ";
$_SESSION["C_LIKE2"]  = "LIKE 2";
$_SESSION["C_CMT"]    = " CMT ";
$_SESSION["C_FOLLOW"] = "FOLLOW";
$_SESSION["C_SHARE"]  = "SHARE ";
$_SESSION["C_PAGE"]   = " PAGE ";
$_SESSION["C_CXCMT"]  = "CX CMT";
$_SESSION["C_LOVE"]   = " LOVE ";
$_SESSION["C_CARE"]   = " CARE ";
$_SESSION["C_HAHA"]   = " HAHA ";
$_SESSION["C_WOW"]    = " WOW  ";
$_SESSION["C_SAD"]    = " SAD  ";
$_SESSION["C_ANGRY"]  = "ANGRY ";
$_SESSION["C_GROUP"]  = "GROUP ";

$_SESSION['useragent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36';
$thanhngang2=$luc."══════════════════════════════════════════════════════════════\n";
$thanhngang3="$vang==========================================================\n";
$thanhngang= $do."------------------------------------------------------------\n";
$thanhngang1=$luc."------------------------------------------------------------\n";
$_SESSION["banner"]="\033[1;32m|════════════════════════════════════════════════════════════|
                \033[1;37mCopyright by Trần Đăng Khoa

\033[1;31m                 ████████╗██████╗ ██╗  ██╗
\033[1;36m                 ╚══██╔══╝██╔══██╗██║ ██╔╝
\033[1;34m                    ██║  ████╗ ██║█████╔╝ 
\033[1;35m                    ██║   ██╔╝ ██║██╔═██╗ 
\033[1;33m                    ██║   ██████╔╝██║  ██╗
\033[1;37m                    ╚═╝   ╚═════╝ ╚═╝  ╚═╝

\033[1;32m║════════════════════════════════════════════════════════════║
\033[1;32m║                                                            ║
\033[1;32m║\033[1;36mGroup Zalo: \033[1;37mhttps://zalo.me/g/zjuifu583                     \033[1;32m║
\033[1;32m║\033[1;35mZalo: \033[1;37m0936763612                                            \033[1;32m║
\033[1;32m║\033[1;33mYoutuber: \033[1;37mTrần Đăng Khoa                                    \033[1;32m║
\033[1;32m║\033[1;31mWebsite: \033[1;37mDichvuquare.com                                    \033[1;32m║
\033[1;32m=>\033[1;34mFacebook: \033[1;37mTrần Đăng Khoa                                   \033[1;32m║
\033[1;32m║════════════════════════════════════════════════════════════║
";
$daucau= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
$thanhngang= $do."------------------------------------------------------------\n";
$thanh_thang_mau_trang = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
function banner(){
    @system('clear');
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') { 
        @system('clear'); 
    } else { 
        @system('cls'); 
    }
    for($i = 0; $i < strlen($_SESSION["banner"]); $i++){echo $_SESSION["banner"][$i];usleep(0.5);}
}
system("clear");
$useragent = "Mozilla/5.0 (Linux; Android 10; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36";
@system('clear');
$daucau2= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') { 
    @system('clear'); 
} else { 
    @system('cls'); 
}
banner();
$listnv = [];

while (true){
if (file_exists("TDS.txt")){
$data = fread(fopen("TDS.txt", "r"), filesize("TDS.txt"));
if ($data == "") { unlink("TDS.txt"); continue; }
$_SESSION['token']= $data;
$login = login();
if (!$login['success']) { unlink("TDS.txt"); continue; }
echo $thanh_dep.$luc."Nhập ".$vang."[".$trang."1".$vang."] ".$luc."Giữ Lại Tài Khoản ".$vang.$_SESSION["username"]."\n";
echo $thanh_dep.$luc."Nhập ".$vang."[".$trang."2".$vang."] ".$luc."Nhập Tài Khoản TDS Mới \n";
echo $thanh_dep.$luc."Nhập ".$trang."===>: $vang";
$chon_tk = trim(fgets(STDIN));
    if ($chon_tk == "2") {
        unlink("TDS.txt");
         
	} else if ($chon_tk == "1") {
    } else {
		echo $do." Lựa chọn không xác định !!!\n"; 
		  continue;
    }
}
if (!file_exists("TDS.txt")){
echo $thanh_dep."\033[1;32mNhập Token TDS: \033[1;33m"; $token = trim(fgets(STDIN));
$file = fopen("TDS.txt", "w+");
fwrite($file, $token);
fclose($file);
}
$data = fread(fopen("TDS.txt", "r"), filesize("TDS.txt"));
$_SESSION["token"] = $data;
$login = login();

if ($login['success']) {
break;
} else {
echo $do." Đăng Nhập Thất Bại.\n";
unlink("TDS.txt");
}
}
@system('clear');
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') { 
    @system('clear'); 
} else { 
    @system('cls'); 
}
banner();
$listig=[];
$stt=0;
while (true){
  $stt++;
  echo $daucau.$luc."Nhập Cookie IG thứ $stt: ".$vang;
  $cookieig=trim(fgets(STDIN));
  if($cookieig==''){
    echo $luc."Thành Công Đã thêm ".$vang.count($listig).$luc." Cookie";
    break;
  }
  array_push($listig,$cookieig);
}
banner();
echo $daucau.$luc."Nhập ".$do."[".$vang."1".$do."]".$luc." Để Chạy Job Tym \n";
echo $daucau.$luc."Nhập ".$do."[".$vang."2".$do."]".$luc." Để Chạy Job Follow \n";
echo $daucau.$luc."Nhập ".$do."[".$vang."3".$do."]".$luc." Để Chạy Job Comment \n";
echo $daucau.$luc."Có thể chạy nhiều nhiệm vụ ".$vang."(1+2)\n";
echo $thanhngang;
echo $daucau.$luc."Nhập Số Để chạy nhiệm vụ: ".$vang;
$nv=trim(fgets(STDIN));
echo $daucau.$luc."Sau bao nhiêu nhiệm vụ thì đổi Nick: ".$vang;
$doiacc=trim(fgets(STDIN));
echo $daucau.$luc."Sau bao nhiêu nhiệm vụ thì dừng tool: ".$vang;
$dungtool=trim(fgets(STDIN));
$listjob=[];
if (strpos($nv, '1') !== false) {
  array_push($listjob,'tym');
}
if (strpos($nv, '2') !== false) {
  array_push($listjob,'follow');
}
if (strpos($nv, '3') !== false) {
  array_push($listjob,'comment');
}
banner();
$stt=0;
while(true){
    $sotk=count($listig);
    for($i=0;$i<$sotk;$i++){
      $cookie=$listig[$i];
      $thongtin=json_decode(dvfb('thongtin',null,null,$cookie),true);
      if($thongtin['status']=='error'){
        echo $do."Cookie die \n";
        unset($listig[$i]);
        if($listig==[]){
          echo "Cookie bạn đã die hết. Vui lòng nhập cookie khác \n";
          die;
        }
        continue;
      }
      echo $luc."Cấu hình: ".$vang.$thongtin['message']['name'].$luc." Id: ".$vang.$thongtin['message']['id']."\n";
      while (true) {
        if (is_array('tym'.$listjob)) {
          $nv = guinv('instagram_like');
          if ($nv['data']) {
            $listnv = $nv['data'];
            $so = 0;
            for ($i = 0; $i < count($listnv); $i++) {
              $link = $listnv[$i]['link'];
              $id = explode('https://www.instagram.com/p/', $link)[1];
              echo $id;
            }
          }
        } else if (is_array('follow'.$listjob)) {
          echo 'Có 2';
        }
      }
      
    }
    sleep(1);
}


/*********[*function*]**********/
function login(){
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://traodoisub.com/api/?fields=profile&access_token='.$_SESSION['token'],
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $js=json_decode($response,true);
    $_SESSION['username']=$js['data']['user'];
    $_SESSION['xu']=$js['data']['xu'];
    return $js;
}
function curltds($url){
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
  ));
  $response = curl_exec($curl);
  curl_close($curl);
  return $response;
}
function guinv($loai){
  $nv=curltds('https://traodoisub.com/api/?fields='.$loai.'&access_token='.$_SESSION['token']);
  echo $nv;
  $js=json_decode($nv,true);
  return $js;
}
function dvfb($loai,$id,$noidung,$cookie){
  $url='https://tool.dichvuquare.com/apiig/?loai='.$loai.'&id='.$id.'&noidung='.urlencode($noidung).'&cookie='.urlencode($cookie);
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
      'authority: tool.dichvuquare.com',
      'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
      'cache-control: max-age=0',
      'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
      'sec-ch-ua-mobile: ?0',
      'sec-ch-ua-platform: "Windows"',
      'sec-fetch-dest: document',
      'sec-fetch-mode: navigate',
      'sec-fetch-site: none',
      'sec-fetch-user: ?1',
      'upgrade-insecure-requests: 1',
      'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
  ]);
  $response = curl_exec($ch);
  curl_close($ch);
  return $response;
}