<?php
$id = "100042441731370"; // Thay thế "your_id" bằng giá trị id thích hợp của bạn
$cookie="sb=QylsZKR_TO7L1Sl6shoFdZv4; datr=QylsZOIIc9oEZOO2-5xsyH7d; locale=vi_VN; dpr=1.375; usida=eyJ2ZXIiOjEsImlkIjoiQXJ3NTdjdDE1dXA1d3giLCJ0aW1lIjoxNjg2NTc3Mjc3fQ%3D%3D; c_user=100087109204883; xs=26%3A1HGq5yfA4rJPXw%3A2%3A1686582686%3A-1%3A6280; fr=0edhQShty1Zhs1qzG.AWWYjonhi5NoUA3ltycZdHvt8MU.BkhzNa.pi.AAA.0.0.Bkhzc7.AWXGCm-O9_w; presence=C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1686583105159%2C%22v%22%3A1%7D; wd=748x678";
///baner
$_SESSION["banner"]="\033[1;32m|════════════════════════════════════════════════════════════|
                \033[1;37mCopyright by Trần Đăng Khoa

\033[1;31m                 ████████╗██████╗ ██╗  ██╗
\033[1;36m                 ╚══██╔══╝██╔══██╗██║ ██╔╝
\033[1;34m                    ██║  ████╗ ██║█████╔╝ 
\033[1;35m                    ██║   ██╔╝ ██║██╔═██╗ 
\033[1;33m                    ██║   ██████╔╝██║  ██╗
\033[1;37m                    ╚═╝   ╚═════╝ ╚═╝  ╚═╝

\033[1;32m║════════════════════════════════════════════════════════════║
\033[1;32m║                                                            ║
\033[1;32m║\033[1;36mGroup Zalo: \033[1;37mhttps://zalo.me/g/zjuifu583                     \033[1;32m║
\033[1;32m║\033[1;35mZalo: \033[1;37m0936763612                                            \033[1;32m║
\033[1;32m║\033[1;33mYoutuber: \033[1;37mTrần Đăng Khoa                                    \033[1;32m║
\033[1;32m║\033[1;31mWebsite: \033[1;37mDichvuquare.com                                    \033[1;32m║
\033[1;32m=>\033[1;34mFacebook: \033[1;37mTrần Đăng Khoa                                   \033[1;32m║
\033[1;32m║════════════════════════════════════════════════════════════║
";
$daucau= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
$thanhngang= $do."------------------------------------------------------------\n";
$thanh_thang_mau_trang = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
function banner(){
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') { 
        @system('clear'); 
    } else { 
        @system('cls'); 
    }
    for($i = 0; $i < strlen($_SESSION["banner"]); $i++){echo $_SESSION["banner"][$i];usleep(0.5);}
}

///hieu ung
function delay($delay)
{
    for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;33m   Trần Đăng Khoa \033[1;31m =>       \033[1;32m LO      \033[1;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;31m    Trần Đăng Khoa \033[0;33m   =>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;32m    Trần Đăng Khoa \033[0;33m    =>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;34m    Trần Đăng Khoa \033[0;33m     => \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m      =>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(140000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m       =>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m        =>\033[0;37m LOADING\033[0;31m | $tt | ";
        usleep(14500);
        echo "\r\e[1;95m    Trần Đăng Khoa                                  \r";
    }
}
$tt = "\r\033[1;31m|\033[1;37m" . $stt . "\033[1;31m|\033[1;91m | \033[1;96m" . date("H:i:s") . "\033[1;91m |\033[1;93m".$loai."\033[1;91m| \033[1;97m" . $id . "\033[1;91m |\033[1;92m +300 \033[1;91m| \033[1;93m" . $sodu . "\e[0m\033[1;91m |\n";
///dichvuquare api
function dvfb($loai,$id,$noidung,$cookie){
    $url='https://tool.dichvuquare.com/api/?loai='.$loai.'&id='.$id.'&noidung='.urlencode($noidung).'&cookie='.urlencode($cookie);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'authority: tool.dichvuquare.com',
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control: max-age=0',
        'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'sec-fetch-dest: document',
        'sec-fetch-mode: navigate',
        'sec-fetch-site: none',
        'sec-fetch-user: ?1',
        'upgrade-insecure-requests: 1',
        'user-agent: TOOL TĐK',
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

///Traodoisub

function thongtinacc($token)
{

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://traodoisub.com/api/?fields=profile&access_token='.$token,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);

curl_close($curl);
return $response;

}
function getnv($loai,$token)
{
  $ch = curl_init();
  $url='https://traodoisub.com/api/?fields='.$loai.'&access_token='.$token;
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
      'authority: traodoisub.com',
      'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
      'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
      'sec-ch-ua-mobile: ?0',
      'sec-ch-ua-platform: "Windows"',
      'sec-fetch-dest: document',
      'sec-fetch-mode: navigate',
      'sec-fetch-site: none',
      'sec-fetch-user: ?1',
      'upgrade-insecure-requests: 1',
      'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
  ]);
  $response = curl_exec($ch);
  
  curl_close($ch);
    return $response;
}
function nhantien($loai, $id, $token)
{
  $curl = curl_init();
  
  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://traodoisub.com/api/coin/?type='.$loai.'&id='.$id.'&access_token='.$token,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
  ));
  
  $response = curl_exec($curl);
  
  curl_close($curl);
    return $response;
}
function datnick($idfb,$token)
{
    $curl = curl_init();
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://traodoisub.com/api/?fields=run&id='.$idfb.'&access_token='.$token,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
    ));
    
    $a = curl_exec($curl);
    
    curl_close($curl);
    return $a;
}
function checkxu($token)
{

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://traodoisub.com/api/?fields=profile&access_token='.$token,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);

curl_close($curl);
$json=json_decode($response,true);
$xu=$json['data']['xu'];
return $xu;

}
function huyfollow($id, $useragent, $cookie)
{
    $ch = curl_init();
    if (strpos($id, '_')) {
        $uid = explode('_', $id, 2);
        $id2 = 'story.php?story_fbid=' . $uid[1] . '&id=' . $uid[0];
    } else {
        $id2 = $id;
    }

    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "cookie:$cookie",
    );
       
    $linkbv = 'https://mbasic.facebook.com/' . $id2;
    curl_setopt($ch, CURLOPT_URL, $linkbv);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
                    :'));
    // json_decode(curl_exec($ch), true);
    $post = curl_exec($ch);

    
    $link = explode('<a href="/a/subscriptions/remove?subject_id=', $post)[1];
    $link = explode('"', $link)[0];
    $link = html_entity_decode($link);
    $link = "https://mbasic.facebook.com/a/subscriptions/remove?subject_id=".$link;
    // echo $link;
    // die();
    $linkreac1 = $link;
    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "referer:$linkbv",
        "cookie:$cookie",
    );
       
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkreac1);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $page = curl_exec($ch);
    $aa = $page;
 
    return $aa;
}
function cmt_fb($id,$cookie,$msg){
    $mr = curl_init();
    $head = [
        "Host:mbasic.facebook.com",
        'sec-ch-ua:"Google Chrome";v="87", " Not;A Brand";v="99", "Chromium";v="87"',
        "sec-ch-ua-mobile:?1",
        "cache-control:max-age=0",
        "upgrade-insecure-requests:1",
        "dnt:1",
        "save-data:on",
        "user-agent:Mozilla/5.0 (Linux; Android 8.1.0; SM-G610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site:same-origin",
        "sec-fetch-mode:navigate",
        "sec-fetch-user:?1",
        "sec-fetch-dest:document",
        "referer:https://mbasic.facebook.com/",
        "accept-language:vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",];
    curl_setopt($mr, CURLOPT_URL, "https://mbasic.facebook.com/$id");
    curl_setopt($mr, CURLOPT_COOKIE, $cookie);
    curl_setopt($mr, CURLOPT_HTTPHEADER, $head);
    curl_setopt($mr, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($mr, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($mr, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($mr, CURLOPT_FOLLOWLOCATION, TRUE);
    $mr2 = curl_exec($mr);
    $fb_dtsg = explode('"',explode('fb_dtsg" value="',$mr2)[1])[0];
    $jazoest = explode('"',explode('jazoest" value="',$mr2)[1])[0];
    $cmt = explode('"',explode('action="/a/comment.php?',$mr2)[1])[0];
    $text = "fb_dtsg=".$fb_dtsg."&jazoest=".$jazoest."&comment_text=".$msg;
    curl_setopt($mr, CURLOPT_URL, "https://mbasic.facebook.com/a/comment.php?".htmlspecialchars_decode($cmt));
    curl_setopt($mr, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($mr, CURLOPT_POSTFIELDS, $text);
    $mr2 = curl_exec($mr);
    curl_close($mr);
    }

///facebook
function follow($idtest, $cookie)
{
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $idtest . '?_rdr');
  $head[] = "Connection: keep-alive";
  $head[] = "Keep-Alive: 300";
  $head[] = "upgrade-insecure-requests: 1";
  // $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
  // $head[] = "Accept-Language: en-us,en;q=0.5";
  // $head[] = "Accept-encoding: gzip, deflate, br";
  // $head[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9";
  $head[] = "sec-ch-ua-mobile: ?0";
  $head[] = "sec-fetch-user: ?1";
  $head[] = "sec-fetch-site: none";
  $head[] = "sec-fetch-dest: document";
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36');
  //curl_setopt($ch, CURLOPT_ENCODING, '');
  curl_setopt($ch, CURLOPT_COOKIE, $cookie);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_REFERER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 60);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
  //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
  $access = curl_exec($ch);
  //return $access;
  $url1 = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
  echo $access;
  if (strpos($access, '/a/subscribe.php?') !== false) {
    $haha = explode('<a href="', $access);
    //$haha2 = null;
    //echo 1;
    for ($v = 0; $v < count($haha); $v++) {
      if (strpos($haha[$v], '/a/subscribe.php?') !== false) {
        $haha2 = explode('" class=', $haha[$v])[0];
        break;
      }
    }
    //if()
    $link2 = html_entity_decode($haha2);
    // echo $url1;
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com' . $link2 . '&_rdr');
    curl_setopt($ch, CURLOPT_REFERER, $url1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $fl = curl_exec($ch);
    //echo curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    //return $fl;
  } else {
    curl_close($ch);
    return 'Lỗi';
    //return $access;
  }
}
function camxuc($id, $type, $cookie) 
{
    $ch = curl_init();
    if (strpos($id, '_')) {
        $uid = explode('_', $id, 2);
        $id2 = 'story.php?story_fbid=' . $uid[1] . '&id=' . $uid[0];
    } else {
        $id2 = $id;
    }
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id2);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
    $page = curl_exec($ch);
    if ($id2 != $id && explode('&amp;origin_uri=', explode('amp;ft_id=', $page, 2)[1], 2)[0]) {
        $get = explode('&amp;origin_uri=', explode('amp;ft_id=', $page, 2)[1], 2)[0];
    } else {
        $get = $id2;
    }
    $link = 'https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id=' . $get;
    curl_setopt($ch, CURLOPT_URL, $link);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $cx = curl_exec($ch);
    $haha = explode('<a href="', $cx);
    if ($type == 'LIKE') {
        $haha2 = explode('" style="display:block"', $haha[1])[0];
    } elseif ($type == 'LOVE') {
        $haha2 = explode('" style="display:block"', $haha[2])[0];
    } elseif ($type == 'CARE') {
        $haha2 = explode('" style="display:block"', $haha[3])[0];
    } else if ($type == 'HAHA') {
        $haha2 = explode('" style="display:block"', $haha[4])[0];
    } else if ($type == 'WOW') {
        $haha2 = explode('" style="display:block"', $haha[5])[0];
    } else if ($type == 'SAD') {
        $haha2 = explode('" style="display:block"', $haha[6])[0];
    } elseif ($type == 'ANGRY') {
        $haha2 = explode('" style="display:block"', $haha[7])[0];
    }
    $link2 = html_entity_decode($haha2);
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com' . $link2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
    curl_close($ch);
}

function thongtin($cookie)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://mbasic.facebook.com/me");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36');
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.110", "Google Chrome";v="114.0.5735.110"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'sec-ch-ua-platform-version: "6.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: none',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'viewport-width: 400'
));

$response = curl_exec($ch);
$redirectUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
curl_close($ch);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $redirectUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'cache-control: max-age=0',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.110", "Google Chrome";v="114.0.5735.110"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'sec-ch-ua-platform-version: "6.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: none',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',
    'viewport-width: 400',
]);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
$response = curl_exec($ch);
curl_close($ch);
if(strpos($response,'profile_id=')){
$name=explode('<head><title>',explode('</title><meta',$response)[0])[1];
$id=explode('&',explode('profile_id=',$response)[1])[0];
return json_encode(array(
    'name'=> $name,
    'id'=> $id
));
}
}
function group_fb($id, $useragent, $cookie)
{
    $ch = curl_init();
    if (strpos($id, '_')) {
        $uid = explode('_', $id, 2);
        $id2 = 'story.php?story_fbid=' . $uid[1] . '&id=' . $uid[0];
    } else {
        $id2 = $id;
    }

    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "cookie:$cookie",
    );
    
    $linkbv = 'https://mbasic.facebook.com/groups/' . $id2;
    curl_setopt($ch, CURLOPT_URL, $linkbv);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
                    :'));
    // json_decode(curl_exec($ch), true);
    $post = curl_exec($ch);


    $link = explode('<form method="post" action="/a/group/join/?group_id=', $post)[1];
    $link = explode('"', $link)[0];
    $link = html_entity_decode($link);
    $link = "https://mbasic.facebook.com/a/group/join/?group_id=" . $link;
    // echo $link;
    // die();
    $linkreac1 = $link;
    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "referer:$linkbv",
        "cookie:$cookie",
    );
       
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkreac1);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $page = curl_exec($ch);
    $aa = $page;

    return $aa;
}
function share($id, $cookie)
{
    $url  = "https://mbasic.facebook.com/" . $id . "";
    $head = array(
        "Host: mbasic.facebook.com",
        "upgrade-insecure-requests: 1",
        "save-data: on",
        "user-agent: Mozilla/5.0 (Linux; Android 10; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*" . "/" . "*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: same-origin",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document",
        "accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5"
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_HEADER => true,
        CURLOPT_COOKIE => $cookie,
        CURLOPT_ENCODING => TRUE
    ));
    $data = curl_exec($ch);
    if (strpos($data, "xs=deleted") == true) {
        print "\033[1;37m~\033[1;33m[\033[1;31mdie\033[1;33m] \033[1;37m=> \033[1;31mCookie Die !!!!\n";
        exit();
    }

    $one = explode("location: ", $data);
    $two = explode("rdr", $one[1]);
    $url = $two[0] . "rdr";
    if ($url == 'rdr') {
    } else {
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_POST => 1,
            CURLOPT_HTTPGET => true,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTPHEADER => $head,
            CURLOPT_HEADER => true,
            CURLOPT_ENCODING => TRUE
        ));
        $a = curl_exec($ch);
        curl_close($ch);
        $data            = explode('"', explode('<a href="/composer/mbasic/?c_src=share&amp;', $a)[1])[0];
        $l1 = explode('amp;', $data)[0];
        $l2 = explode('amp;', $data)[1];
        $l3 = explode('amp;', $data)[2];
        $l4 = explode('amp;', $data)[3];
        $l5 = explode('amp;', $data)[4];
        $l6 = explode('amp;', $data)[5];
        $l7 = explode('amp;', $data)[6];
        $l8 = explode('amp;', $data)[7];
        $l9 = explode('amp;', $data)[8];
        $l10 = explode('amp;', $data)[9];
        $l11 = explode('amp;', $data)[10];
        $link = "https://mbasic.facebook.com/composer/mbasic/?c_src=share&" . $l1 . "" . $l2 . "" . $l3 . "" . $l4 . "" . $l5 . "" . $l6 . "" . $l7 . "" . $l8 . "" . $l9 . "" . $l10 . "" . $l11 . "";
    }
    #begin
    $head = array(
        "Host: mbasic.facebook.com",
        "cache-control: max-age=0",
        "save-data: on",
        "upgrade-insecure-requests: 1",
        "user-agent: Mozilla/5.0 (Linux; Android 10; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36",
        "referer: https://mbasic.facebook.com/home.php",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "sec-fetch-site: none",
        "sec-fetch-mode: navigate",
        "sec-fetch-user: ?1",
        "sec-fetch-dest: document"
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $link,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_HTTPGET => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $cookie,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $data = curl_exec($ch);
    curl_close($ch);
    $a            = explode('" id="composer_form"', explode('<form method="post" action="', $data)[1])[0];
    $a1 = explode('amp;', $a)[0];
    $a2 = explode('amp;', $a)[1];
    $a3 = explode('amp;', $a)[2];
    $a4 = explode('amp;', $a)[3];
    $link2 = "https://mbasic.facebook.com" . $a1 . "" . $a2 . "" . $a3 . "" . $a4 . "&ref=dbl";
    $fb_dtsg            = explode('" autocomplete="off"', explode('name="fb_dtsg" value="', $data)[1])[0];
    $jazoest            = explode('" autocomplete="off"', explode('name="jazoest" value="', $data)[1])[0];
    $target            = explode('"', explode('name="target" value="', $data)[1])[0];
    $csid            = explode('"', explode('name="csid" value="', $data)[1])[0];
    $privacyx            = explode('"', explode('name="privacyx" value="', $data)[1])[0];
    $cver            = explode('"', explode('name="cver" value="', $data)[1])[0];
    $m            = explode('"', explode('name="m" value="', $data)[1])[0];
    $shared_from_post_id            = explode('"', explode('name="shared_from_post_id" value="', $data)[1])[0];
    $cscr            = explode('"', explode('name="c_src" value="', $data)[1])[0];
    $referrer            = explode('"', explode('name="referrer" value="', $data)[1])[0];
    $ctype            = explode('"', explode('name="ctype" value="', $data)[1])[0];
    $sid            = explode('"', explode('name="sid" value="', $data)[1])[0];
    $waterfall_source            = explode('"', explode('name="waterfall_source" value="', $data)[1])[0];
    #break;
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $t = date('d-m-Y | H:i:s');
    $data = "comment=Hợp Tool&m=oneclick&privacyx=" . $privacyx . "&sid=" . $sid . "&shareID=" . $sid . "&fs=1&fr=null&internal_preview_image_id=null&should_share_post=false&direct=true&_ft_=" . $l11 . "&fb_dtsg=" . $fb_dtsg . "&jazoest=" . $jazoest . "__dyn=1KQEGiFo525Ujwh8-F42mml3onxG6UO3m2i5UfXwNwTwKwSwMxWUW16wZxm6Uhx6485-0SUhxm3O0AE8o11E52q3q5U2nweS787S78K1Jwt8-0lm68WUS2F0EU6i12wm8qwk888C0NEeo5Wq3q0H8-7E2swp82vwAwmE2ewnE2Lw5dw&__csr=&__req=7&__a=AYmQRaSRpckx8Ugg8YkSOfYUUczZWHGSt_e3GRCVZ-yzwoxI0JMFbt_4bf2bG-XPk4FOLrTs5QEGOofdlpo6f5hUReNVHgYej0SSg1hYsLZoMQ&__user=" . $target . "";
    $header = array(
        "Host: m.facebook.com",
        "content-length: " . strlen($data),
        "origin: https://m.facebook.com",
        "x-requested-with: XMLHttpRequest",
        "user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Kiwi Chrome/68.0.3438.0 Safari/537.36",
        "x-response-format: JSONStream",
        "content-type: application/x-www-form-urlencoded",
        "accept: */*",
        "referer: https://m.facebook.com/"
    );
    $ch   = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => 'https://m.facebook.com/a/sharer.php',
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_COOKIE => $cookie,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_ENCODING => TRUE
    ));
    $data = curl_exec($ch);
    curl_close($ch);
}
function group_fb($id, $useragent, $cookie)
{
    $ch = curl_init();
    if (strpos($id, '_')) {
        $uid = explode('_', $id, 2);
        $id2 = 'story.php?story_fbid=' . $uid[1] . '&id=' . $uid[0];
    } else {
        $id2 = $id;
    }

    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "cookie:$cookie",
    );
    
    $linkbv = 'https://mbasic.facebook.com/groups/' . $id2;
    curl_setopt($ch, CURLOPT_URL, $linkbv);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
                    :'));
    // json_decode(curl_exec($ch), true);
    $post = curl_exec($ch);


    $link = explode('<form method="post" action="/a/group/join/?group_id=', $post)[1];
    $link = explode('"', $link)[0];
    $link = html_entity_decode($link);
    $link = "https://mbasic.facebook.com/a/group/join/?group_id=" . $link;
    // echo $link;
    // die();
    $linkreac1 = $link;
    $header = array(
        "Host:mbasic.facebook.com",
        "user-agent:$useragent",
        "accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "referer:$linkbv",
        "cookie:$cookie",
    );
       
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $linkreac1);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    $page = curl_exec($ch);
    $aa = $page;

    return $aa;
}
function page($id, $cookie)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/' . $id);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect
	:'));
    $page = curl_exec($ch);
    if (explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0]) {
        $get = explode('&amp;refid=', explode('pageSuggestionsOnLiking=1&amp;gfid=', $page)[1])[0];
        $link = 'https://mbasic.facebook.com/a/profile.php?fan&id=' . $id . '&origin=page_profile&pageSuggestionsOnLiking=1&gfid=' . $get . '&refid=17';
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
    }
    curl_close($ch);
}
<?php
function listadd($cookie){
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/friends/center/mbasic/');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
      'authority: mbasic.facebook.com',
      'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
      'cache-control: max-age=0',
      'sec-ch-prefers-color-scheme: light',
      'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
      'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.134", "Google Chrome";v="114.0.5735.134"',
      'sec-ch-ua-mobile: ?0',
      'sec-ch-ua-platform: "Windows"',
      'sec-ch-ua-platform-version: "15.0.0"',
      'sec-fetch-dest: document',
      'sec-fetch-mode: navigate',
      'sec-fetch-site: none',
      'sec-fetch-user: ?1',
      'upgrade-insecure-requests: 1',
      'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
      'viewport-width: 1010',
  ]);
  curl_setopt($ch, CURLOPT_COOKIE, $cookie);
  $response = curl_exec($ch);
  curl_close($ch);
  $links=[];
  if (strpos($response, 'href="/a/friends/add/?') !== false) {
      $a=explode('href="/a/friends/add/?',$response);
      $sllist = count($a)-1;
      for ( $i=1; $i < $sllist;  $i++){
        $a=explode('"',explode('href="/a/friends/add/?',$response)[$i])[0];
        $a="https://mbasic.facebook.com/a/friends/add/?".str_replace("amp;","",$a);
        $links[]=$a;
      }
  }
  return $links;
}

