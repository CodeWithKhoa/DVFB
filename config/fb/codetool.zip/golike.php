<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
echo date("Y-m-d H:i:s");
$authorization='Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvc3YyLmdvbGlrZS5uZXRcL2FwaVwvbG9naW4iLCJpYXQiOjE2ODgzODg0NDgsImV4cCI6MTcxOTkyNDQ0OCwibmJmIjoxNjg4Mzg4NDQ4LCJqdGkiOiJuYlhrR2lwMENkNW5MdzA0Iiwic3ViIjoyMTUwNzQ5LCJwcnYiOiJiOTEyNzk5NzhmMTFhYTdiYzU2NzA0ODdmZmYwMWUyMjgyNTNmZTQ4In0.f49wIRWZjd9ubQgB7WUYHrMgFV9jvM0IM9NaVucAaSc';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://sv5.golike.net/api/users/me');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: sv5.golike.net',
    'accept: application/json, text/plain, */*',
    'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
    'authorization: '.$authorization,
    'content-type: application/json;charset=utf-8',
    'origin: https://app.golike.net',
    'referer: https://app.golike.net/',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'sec-fetch-dest: empty',
    'sec-fetch-mode: cors',
    'sec-fetch-site: same-site',
    't: VFZSWk5FOVVXVE5PUkVsNVRXYzlQUT09',
    'user-agent: Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',
]);

$response = curl_exec($ch);
echo $response;
curl_close($ch);
$js=json_decode($response,true);
if($js['status']!==200){
    exit("Authorization Sai vui lòng nhập lại.\n");
}
$array = array(
    "user" => array(
        "id" => 1072241,
        "username" => $js['data']['username'],
        "counter_rechecking" => 0,
        "user_id" => $js['data']['id'],
        "fb_id" => $js['data']['fb_id'],
        "fb_name" => $js['data']['name'],
        "avatar" => null,
        "avatar_url" => null,
        "status" => 1,
        "counter_jobs_today" => 0,
        "is_banned" => 0,
        "allow_comment" => 0,
        "location" => null,
        "is_paid_now" => 0,
        "latest_time_complete_jobs" => null,
        "description" => null,
        "verified_at" => date("Y-m-d H:i:s"),
        "created_at" => date("Y-m-d H:i:s"),
        "updated_at" => date("Y-m-d H:i:s"),
        "gender" => null,
        "age" => null,
        "birthday" => null,
        "friends" => "2033",
        "public_subscriptions" => 0,
        "jobs_can_work" => array(
            "follow" => $js['data']['follow'],
            "like_page" => 0
        ),
        "has_jobs_rechecking" => 0,
        "role" => $js['data']['role'],
        "load_job_like_clone" => true,
        "data" => null,
        "client" => null
    )
);

$jsonString = json_encode($array);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.golike.net/api/job');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: api.golike.net',
    'accept: application/json, text/plain, */*',
    'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type: application/json;charset=UTF-8',
    'origin: https://app.golike.net',
    'referer: https://app.golike.net/',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'sec-fetch-dest: empty',
    'sec-fetch-mode: cors',
    'sec-fetch-site: same-site',
    'user-agent: Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonString);

$response = curl_exec($ch);
echo $response;
curl_close($ch);
