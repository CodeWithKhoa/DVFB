<?php

error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
/***[ Config ]***/
$gioi_han_job = 2;
/***[ USERAGENT ]***/
$useragent = "Mozilla/5.0 (Linux; Android 10; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36";
/***[ Đánh Dấu Bản Quyền ]***/
$thanhngang = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
/***[ Delay ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    $_SESSION['load'] = 0.5;
    $_SESSION['delay'] = 2000;
} else {
    $_SESSION['load'] = 0;
    $_SESSION['delay'] = 1000;
}
/***[ Banner ]***/
date_default_timezone_set('Asia/Ho_Chi_Minh');
error_reporting(0);
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$whiteb="\033[1;37m";
$red="\033[0;31m";
$redb="\033[1;31m";
/***[ Đánh Dấu Bản Quyền ]***/
$daucau= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
$thanhngang = "\033[1;31m────────────────────────────────────────────────────────────\n";
/***[ USERAGENT ]***/
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
/***[ Delay ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
        $_SESSION['load'] = 0.5;
        $_SESSION['delay'] = 150000;
} else {
        $_SESSION['load'] = 0;
        $_SESSION['delay'] = 100000;
}
if(!$_SESSION['version']) {
        $_SESSION['version'] = "3.9";
}
/***[ Config ]***/
$job = 8;
/***[ Banner ]***/
$banner="\033[1;32m|════════════════════════════════════════════════════════════|
                \033[1;37mCopyright by Trần Đăng Khoa

\033[1;31m                 ████████╗██████╗ ██╗  ██╗
\033[1;36m                 ╚══██╔══╝██╔══██╗██║ ██╔╝
\033[1;34m                    ██║  ████╗ ██║█████╔╝ 
\033[1;35m                    ██║   ██╔╝ ██║██╔═██╗ 
\033[1;33m                    ██║   ██████╔╝██║  ██╗
\033[1;37m                    ╚═╝   ╚═════╝ ╚═╝  ╚═╝

\033[1;32m║════════════════════════════════════════════════════════════║
\033[1;32m║                                                            ║
\033[1;32m║\033[1;36mGroup Zalo: \033[1;37mhttps://zalo.me/g/zjuifu583                     \033[1;32m║
\033[1;32m║\033[1;35mZalo: \033[1;37m0936763612                                            \033[1;32m║
\033[1;32m║\033[1;33mYoutuber: \033[1;37mTrần Đăng Khoa                                    \033[1;32m║
\033[1;32m║\033[1;31mWebsite: \033[1;37mDichvuquare.com                                    \033[1;32m║
\033[1;32m=>\033[1;34mFacebook: \033[1;37mTrần Đăng Khoa                                   \033[1;32m║
\033[1;32m║════════════════════════════════════════════════════════════║
";
$thanhngang= $do."------------------------------------------------------------\n";

/***[ Clear + Thông Số Admin ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') { 
    @system('clear'); 
} else { 
    @system('cls'); 
}
for($i = 0; $i < strlen($banner); $i++){echo $banner[$i];usleep(0.5);}
$khoTDS =[];
while(true){
@system("clear");
echo $banner;
   if (file_exists('taikhoantds.txt'))
    {
        echo $daucau.$luc."Nhập Số ".$do."[".$vang."1".$do."]".$luc." Để Chạy Tài Khoản TDS Đã Lưu \n";
        echo $daucau.$luc."Nhập Số ".$do."[".$vang."2".$do."]".$luc." Để Chạy Tài Khoản TDS Mới\n";
        echo $thanhngang;
        echo $daucau.$luc."Vui Lòng Nhập Lựa Chọn$trang: \033[1;33m";
        $cookietds = trim(fgets(STDIN));
        if ($cookietds == "2" )
        {
            unlink('taikhoantds.txt');
        }else{}
    }else{
        echo $daucau.$luc."Nhập Tài Khoản TĐS$trang: $vang";
        $tktds = trim(fgets(STDIN));
        echo $daucau.$luc."Nhập Mật Khẩu TĐS$trang: $vang";
        $mktds = trim(fgets(STDIN));
        array_push($khoTDS,$tktds);
        array_push($khoTDS,$mktds);
        $js=json_encode($khoTDS);
        $k = fopen("taikhoantds.txt","a+");
        fwrite($k, $js);
        fclose($k);
        }
        if (file_exists('taikhoantds.txt')){
        $khoTDS = json_decode(fread(fopen("taikhoantds.txt","r"),filesize("taikhoantds.txt")),true);
        $username = $khoTDS[0];
        $password = $khoTDS[1];
        }
    $data = 'username='.$username.'&password='.$password;
    $mr = curl_init();
    curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/login.php');
    curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($mr, CURLOPT_COOKIEJAR, 'file.txt');
    curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
    curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
    $mr2 = curl_exec($mr); 
    curl_close($mr); 
    $dn = explode('success":', $mr2)[1];
    $dn = explode('}', $dn)[0];
    if($dn == 'true'){
    echo $xnhac."Đăng Nhập Thành Công\n";
    sleep(0.1);
    break;
    }else{
    echo $do."Sai Tài Khoản Hoặc Mật Khẩu \n";
    sleep(0.1);
    unlink('taikhoantds.txt');
    }
}
while(true){
    echo $thanhngang;

    $khoTT = [];
    $file='idyoutube.txt';
    if (file_exists($file) && filesize($file) === 0) {
        unlink('idyoutube.txt');
    }
    if (file_exists('idyoutube.txt'))
    {
        echo $daucau.$luc."Nhập Số ".$do."[".$vang."1".$do."]".$luc." Để Chạy ID YouTube Đã Lưu \n";
        echo $daucau.$luc."Nhập Số ".$do."[".$vang."2".$do."]".$luc." Để Chạy ID YouTube Mới\n";
        echo $daucau.$luc."Vui Lòng Nhập Lựa Chọn$trang: \033[1;33m";
        $cookietds = trim(fgets(STDIN));
        if ($cookietds == "2" )
        {
            unlink('idyoutube.txt');
        }else{}
    }else{
            echo $daucau.$luc."Vào Web TDS Sao Chép ID YouTube Đang Cấu Hình \n";
            echo $daucau.$luc."Nhập ID Youtube Cấu Hình TDS$trang: $vang";
        $idyt = trim(fgets(STDIN));
        array_push($khoTT,$idyt);
        $js=json_encode($khoTT);
        $k = fopen("idyoutube.txt","a+");
        fwrite($k, $js);
        fclose($k);
        }
        if (file_exists('idyoutube.txt'))
    {
        $khoTT = json_decode(fread(fopen("idyoutube.txt","r"),filesize("idyoutube.txt")),true);
        $idyoutube = $khoTT[0];
    }

    // cấu hình
    $header = array( 
        "Host:traodoisub.com",
        "content-type:application/x-www-form-urlencoded; charset=UTF-8",
        "x-requested-with:XMLHttpRequest",
        "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
        "origin:https://traodoisub.com",
        "referer:https://traodoisub.com/view/chyoutube/",
        );
        $data = 'iddat='.$idyoutube;
        $mr = curl_init();
        curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/scr/youtube_datnick.php');
        curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
        curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
        curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
        curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
        $mr2 = curl_exec($mr); 
        curl_close($mr);
        echo $mr2;
        if($mr2 == '1'){
        echo $xnhac."Cấu Hình Thành Công \n";
        break;
        die;
        }else{
            echo $do."Cấu Hình Thất Bại";
            sleep(2);
        }

}

// lấy xu
$header = array( 
    "Host:traodoisub.com",
    "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
    "referer:https://traodoisub.com/view/setting/",
    );
    $mr = curl_init();
    curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/view/setting/load.php');
    curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
    curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
    curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
    $mr2 = curl_exec($mr); 
    curl_close($mr);
    $xu = explode('xu":"', $mr2)[1];
    $xu = explode('"', $xu)[0];
    
    $user = explode('user":"', $mr2)[1];
    $user = explode('"', $user)[0];
system('clear');
echo $banner;
echo $daucau.$luc."Tên Tài Khoản: \033[1;93m$user\n";
echo $daucau.$luc."Xu Hiện Tại: \033[1;93m$xu \n";
while(true){
    
    echo $thanhngang;
    echo $daucau.$luc."Nhập Số ".$do."[".$vang."1".$do."]".$luc." Để Chạy Nhiệm Vụ Subscribe\n";
    echo $daucau.$luc."Nhập Số ".$do."[".$vang."2".$do."]".$luc." Để Chạy Nhiệm Vụ Comment \n";
    echo $thanhngang;
    echo $daucau.$luc."Vui Lòng Nhập Chế Độ$trang: $vang";
    $nhiemvu = trim(fgets(STDIN));
    echo $daucau.$luc."Nhập Delay \033[1;31m(\033[1;33mTrên 15s\033[1;31m)$trang: $vang";
    $delay = trim(fgets(STDIN));
    if($delay < 15)
		{exit($daucau."\033[1;91mÍt Nhất 15 Giây\n");}
$tool = "\033[1;92mTraoDoiSub Youtube";
    echo $thanhngang;


$spam = 0;
while(true){

    if($spam == 1){
        break;
    }

    if($nhiemvu == 1){

        

        // lấy id follow
        $header = array( 
        "Host:traodoisub.com",
        "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
        "referer:https://traodoisub.com/ex/youtube_follow/",
        );
        $mr = curl_init();
        curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_follow/load.php');
        curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
        curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
        curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
        $mr2 = curl_exec($mr); 
            curl_close($mr); 

            $id = explode('id":"', $mr2)[2];
            $id = explode('"', $id)[0];
            
            $aidi = substr($id,22);
            
            $link = explode('link":"', $mr2)[1];
            $link = explode('"', $link)[0];

            $type = explode('type":"', $mr2)[1];
            $type = explode('"', $type)[0];
            
            $link2 = substr($link,27);
            $link = "https://youtube.com/".$link2;

            if($id == ''){
                $demhetnv++;
                if($demhetnv == 5){
                    $demhetnv = 0;
                    $spam = 1;
                    break;
                }
            }else{
                $demhetnv = 0;
            $dem++;
            
           $kl = "\033[1;31m[\033[1;33m".$dem."\033[1;31m]\033[1;91m | \033[1;36m".date("H:i:s")."\033[1;31m | \033[1;33mSubscribe\033[1;31m | \033[1;37m".$link2." \n";
 for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(1000);}
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
                @system('xdg-open '.$link);
            } else {
                @system('cmd /c start '.$link);
            }
            delay ($delay);
            // làm job
            $header = array( 
                "Host:traodoisub.com",
                "content-type:application/x-www-form-urlencoded; charset=UTF-8",
                "x-requested-with:XMLHttpRequest",
                "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
                "origin:https://traodoisub.com",
                "referer:https://traodoisub.com/ex/youtube_follow/",
                );
                $data = 'id='.$id.'&type='.$type.'';
                $mr = curl_init();
                curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_follow/cache.php');
                curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
                curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
                curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
                curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
                $mr2 = curl_exec($mr); 
                curl_close($mr);
            
                
                 // nhận tiền
                $header = array( 
                    "Host:traodoisub.com",
                    "content-type:application/x-www-form-urlencoded; charset=UTF-8",
                    "x-requested-with:XMLHttpRequest",
                    "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
                    "origin:https://traodoisub.com",
                    "referer:https://traodoisub.com/ex/youtube_follow/",
                    );
                    $data = 'key=0257272C744254';
                    $mr = curl_init();
                    curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_follow/nhantien.php');
                    curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
                    curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
                    curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
                    curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
                    $mr2 = curl_exec($mr); 
                    curl_close($mr);
                    $json = json_decode($mr2, true);
                    $ok = explode('code": "', $mr2)[1];
                    $ok = explode('"', $ok)[0];
                    
                    $xu = explode('xu": ', $mr2)[1];
                    $xu = explode(',', $xu)[0];
                    
                    $nt = explode('ng', $mr2)[1];
                    $nt  = explode('"', $nt)[0];

            if($ok == "success"){
                
                echo "\033[1;36m Nhận Thành Công ".$nt."\033[1;31m |\033[1;33m $xu \n";
   }else{
            }

        }
        

        }elseif($nhiemvu == 2){



        // lấy id cmt
        $header = array( 
            "Host:traodoisub.com",
            "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
            "referer:https://traodoisub.com/ex/youtube_comment/",
            );
            $mr = curl_init();
            curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_comment/load.php');
            curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($mr, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
            curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
            curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
            $mr2 = curl_exec($mr); 
            curl_close($mr);
            $json = json_decode($mr2, true);
            
            $id = explode('id":"', $mr2)[2];
            $id = explode('"', $id)[0];
            
            $aidi = substr($id,22);
            
            $link = explode('link":"', $mr2)[1];
            $link = explode('"', $link)[0];
            
            $type = explode('type":"', $mr2)[1];
            $type = explode('"', $type)[0];
            
            $msg = explode('msg":"', $mr2)[1];
            $msg = explode('"', $msg)[0];
            
            $msg1 = $json["data"][0]["msg"];
            
            $link2 = substr($link,27);
            
            $link = "https://youtube.com/".$link2;


            if($id == ''){
                $demhetnv++;
                if($demhetnv == 5){
                    $demhetnv = 0;
                    $spam = 1;
                    break;
                }
            }else{
                $demhetnv = 0;
                $dem++;
                $kl = "\033[1;31m[\033[1;33m".$dem."\033[1;31m] \033[1;31m● \033[1;32m\033[1;36m".date("H:i:s")."\033[1;32m \033[1;31m● \033[1;".rand(31,37)."m"."Comment \033[1;".rand(31,37)."m"."| \033[1;37mhttps://youtube.com/".$link2." \033[1;91m| \033[1;97mNội Dung: ".$msg1."\n";
                for($i = 0; $i < strlen($kl); $i++){echo $kl[$i];usleep(500);}
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
	
                    @system('xdg-open '.$link);
                } else {
                    @system('cmd /c start '.$link);
                }
                delay ($delay);
                // làm job
                $header = array( 
                    "Host:traodoisub.com",
                    "content-type:application/x-www-form-urlencoded; charset=UTF-8",
                    "x-requested-with:XMLHttpRequest",
                    "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
                    "origin:https://traodoisub.com",
                    "referer:https://traodoisub.com/ex/youtube_comment/",
                    );
                    $data = 'id='.$id.'&type='.$type.'';
                    $mr = curl_init();
                    curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_comment/cache.php');
                    curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
                    curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
                    curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
                    curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
                    $mr2 = curl_exec($mr); 
                    curl_close($mr);
                
                    
                     // nhận tiền
                    $header = array( 
                        "Host:traodoisub.com",
                        "content-type:application/x-www-form-urlencoded; charset=UTF-8",
                        "x-requested-with:XMLHttpRequest",
                        "user-agent:Mozilla/5.0 (Linux; Android 10; SM-J610F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.1.4638.113 Mobile Safari/537.36",
                        "origin:https://traodoisub.com",
                        "referer:https://traodoisub.com/ex/youtube_comment/",
                        );
                        $data = 'id='.$id.'&type='.$type.'';
                        $mr = curl_init();
                        curl_setopt($mr, CURLOPT_URL, 'https://traodoisub.com/ex/youtube_comment/nhantien.php');
                        curl_setopt($mr, CURLOPT_RETURNTRANSFER, TRUE);
                        curl_setopt($mr, CURLOPT_COOKIEFILE, 'file.txt');
                        curl_setopt($mr, CURLOPT_POSTFIELDS, $data);
                        curl_setopt($mr, CURLOPT_HTTPHEADER, $header);
                        curl_setopt($mr, CURLOPT_USERAGENT, $useragent);
                        $mr2 = curl_exec($mr); 
                        curl_close($mr);
                        $json = json_decode($mr2, true);
                $ok = explode('code": "', $mr2)[1];
                $ok = explode('"', $ok)[0];
                
                $xu = explode('xu": ', $mr2)[1];
                $xu = explode(',', $xu)[0];
                
                $nt = explode('ng', $mr2)[1];
                $nt  = explode('"', $nt)[0];
                if($ok == "success"){
                    echo "\e[1;32mSuccess\033[1;34m\033[1;".rand(31,37)."m =>\033[1;91m \033[1;33m Nhận Thành Công".$nt."\033[1;37m |\033[1;33m $xu\n";
                }else{
                }
           }
        }
    }
}
function delay($delay)
{
    for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;33m   Trần Đăng Khoa \033[1;31m =>       \033[1;32m LO      \033[1;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;31m    Trần Đăng Khoa \033[0;33m   =>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;32m    Trần Đăng Khoa \033[0;33m    =>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;34m    Trần Đăng Khoa \033[0;33m     => \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m      =>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(140000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m       =>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m        =>\033[0;37m LOADING\033[0;31m | $tt | ";
        usleep(14500);
        echo "\r\e[1;95m    Trần Đăng Khoa                                  \r";
    }
}
function tdsyoutube($banner, $daucau, $thanhngang){
    for($i = 0; $i < strlen($banner); $i++){echo $banner[$i];usleep($_SESSION['load']);}
    echo "\n";
}