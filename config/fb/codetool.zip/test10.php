<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://temp-mail.org/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: temp-mail.org',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'referer: https://temp-mail.org/en/view/64b2572d37921a0ef0b0b574',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'accept-encoding: gzip',
]);
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookiemail.txt');

$response = curl_exec($ch);

curl_close($ch);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://temp-mail.org/en/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: temp-mail.org',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'referer: https://temp-mail.org/en/view/64b2572d37921a0ef0b0b574',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
]);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookiemail.txt');

$response = curl_exec($ch);
echo $response;
curl_close($ch);
$token=explode(';',explode('token=',file_get_contents('cookiemail.txt'))[1])[0];
echo $token;
die;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'cache-control: max-age=0',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: none',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 975',
]);
curl_setopt($ch, CURLOPT_COOKIEJAR, 'fbb.txt');

$response = curl_exec($ch);
curl_close($ch);
sleep(3);
$data = [
    'lsd' => explode('"',explode('"lsd" value="',$response)[1])[0],
    'jazoest' => explode('"',explode('name="jazoest" value="',$response)[1])[0],
    'm_ts' => explode('"',explode('name="m_ts" value="',$response)[1])[0],
    'li' => explode('"',explode('name="li" value="',$response)[1])[0],
    'try_number' => explode('"',explode('name="try_number" value="',$response)[1])[0],
    'unrecognized_tries' => explode('"',explode('name="unrecognized_tries" value="',$response)[1])[0],
    'email' => '',
    'pass' => '',
    'sign_up' => 'Tạo tài khoản mới',
    'bi_xrwh' => 0
];
$dataString = http_build_query($data);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=100&refid=8');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'cache-control: max-age=0',
    'content-type: application/x-www-form-urlencoded',
    'origin: https://mbasic.facebook.com',
    'referer: https://mbasic.facebook.com/',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 975',
]);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'fbb.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

$response = curl_exec($ch);
curl_close($ch);
sleep(3);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/reg/?cid=103&refsrc=deprecated&_rdr');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'cache-control: max-age=0',
    'referer: https://mbasic.facebook.com/',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 981',
]);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'fbb.txt');

$response = curl_exec($ch);

curl_close($ch);
sleep(3);
echo $response."\n";
$data = [
    'lsd' => explode('"',explode('name="lsd" value="',$response)[1])[0],
    'jazoest' => explode('"',explode('name="jazoest" value="',$response)[1])[0],
    'ccp' => explode('"',explode('name="ccp" value="',$response)[1])[0],
    'reg_instance' => explode('"',explode('name="reg_instance" value="',$response)[1])[0],
    'submission_request' => explode('"',explode('name="submission_request" value="',$response)[1])[0],
    'helper' => '',
    'reg_impression_id' => explode('"',explode('name="reg_impression_id" value="',$response)[1])[0],
    'ns' => explode('"',explode('name="ns" value="',$response)[1])[0],
    'zero_header_af_client' => '',
    'app_id' => '',
    'logger_id' => '',
    'field_names' => [
        'firstname',
        'reg_email__',
        'sex',
        'birthday_wrapper',
        'reg_passwd__'
    ],
    'lastname' => 'Trần',
    'firstname' => 'Văn',
    'reg_email__' => 'lisoy65592@msback.com',
    'sex' => '2',
    'custom_gender' => '',
    'did_use_age' => 'false',
    'birthday_day' => '10',
    'birthday_month' => '12',
    'birthday_year' => '1992',
    'age_step_input' => '',
    'reg_passwd__' => 'Tr@nd@ngkho@',
    'submit' => 'Đăng ký'
];  

$dataString = http_build_query($data);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://mbasic.facebook.com/reg/submit/?cid=103');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'authority: mbasic.facebook.com',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: vi-VN,vi;q=0.9',
    'cache-control: max-age=0',
    'content-type: application/x-www-form-urlencoded',
    'origin: https://mbasic.facebook.com',
    'referer: https://mbasic.facebook.com/reg/?cid=103&refsrc=deprecated&_rdr',
    'sec-ch-prefers-color-scheme: light',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-full-version-list: "Not.A/Brand";v="8.0.0.0", "Chromium";v="114.0.5735.199", "Google Chrome";v="114.0.5735.199"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-platform-version: "15.0.0"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'viewport-width: 981',
]);
curl_setopt($ch, CURLOPT_COOKIEFILE, 'fbb.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

$response = curl_exec($ch);

curl_close($ch);
echo $response;