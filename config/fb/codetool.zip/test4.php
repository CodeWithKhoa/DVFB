<?php
///
$put=trim(fgets(STDIN));
$thay1=" ";
$thay2="',
'";
$dataarray=str_replace("=>","'=> '","'".str_replace($thay1,$thay2,str_replace(": ","=>",$put))."'");
echo $dataarray;
//$data=http_build_query($arraydata);