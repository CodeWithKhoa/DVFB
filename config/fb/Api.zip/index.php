<?php
header('Content-Type: text/html; charset=utf-8');
require_once ($_SERVER['DOCUMENT_ROOT'].'/404.php');
?>