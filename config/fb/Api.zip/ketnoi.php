<?php
$servername = "localhost";
$username = "mvntktbv_tool";
$password = "mvntktbv_tool";
$dbname = "mvntktbv_tool";

// Create connection
$ketnoi = mysqli_connect($servername, $username, $password, $dbname);
mysqli_set_charset($ketnoi, "utf8");