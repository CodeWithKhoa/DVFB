<?php
header('Content-Type: text/html; charset=utf-8');
$userAgent = $_SERVER['HTTP_USER_AGENT'];
if($userAgent!='TOOL TĐK'){
    require_once ($_SERVER['DOCUMENT_ROOT'].'/404.php');
    die;
}
?>
#TOOL TĐK
/***[ Color ]***/
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
$no="\033[0m";
$den="\033[1;30m";
$do="\033[1;31m";
$xanhl="\033[1;32m";
$vang="\033[1;33m";
$tim="\033[1;34m";
$hong="\033[1;35m";
$xanht="\033[1;36m";
$trang="\033[1;37m";
/***[ Delay ]***/
if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
    $_SESSION['load'] = 1200;
    $_SESSION['delay'] = 2000;
} else {
    $_SESSION['load'] = 0;
    $_SESSION['delay'] = 1000;
}
$daucau= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
$thanhngang= $do."------------------------------------------------------------\n";
$thanh_thang_mau_trang = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";

@system("clear");
banner();
echo $daucau.$luc."Nhập Cookie Facebook: ".$vang;
$cookie=readline();
$check=json_decode(dvfb('thongtin','','',$cookie),true);
if($check['status']=='error'){
    echo $do."Cookie die \n";
    die;
}
$namefb=$check['message']['name'];
$idfb=$check['message']['id'];
echo $luc."Tên FB: ".$trang.$namefb.$luc." ID FB: ".$trang.$idfb."\n";

echo $daucau.$luc."Nhập ID Box hoặc người dùng cần spam: ".$vang;
$idsp=readline();
echo $daucau.$luc."Bạn muốn đếm ở đâu thì chọn".$trang.' {'.$vang.'$so'.$trang."} ".$luc."nếu không thì thôi \n";
echo $daucau.$luc."Nhập Nội Dung: ".$vang;
$noidung=" ".readline();

echo $daucau.$luc."Nhập số lần spam: ",$vang;
$solan=readline();

echo $daucau.$luc."Nhập Delay: ".$vang;
$delay=readline();
@system('clear');
banner();
echo $thanhngang;
echo $luc."Tên FB:$vang $namefb$luc ID FB:$vang $idfb \n";
echo $thanhngang;
$stt=0;
while(true){
    $stt++;
    if(strpos($noidung,'{$so}')){
        $nd=str_replace('{$so}',$stt,$noidung);
    } else {
        $nd=$noidung;
    }
    $spam=json_decode(dvfb('messages',$idsp,$nd,$cookie),true);
    if($spam['status']=='error'){
        echo "\r".$spam['message']."\r" ;
        die;
    }
    $loai='SPAM MESSENGES';
    $tt = "\r\033[1;31m|\033[1;37m" . $stt . "\033[1;31m|\033[1;91m | \033[1;96m" . date("H:i:s") . "\033[1;91m |\033[1;93m".$loai."\033[1;91m| \033[1;97m" . $idsp . "\033[1;91m |\n";
    for($i=0;$i<strlen($tt);$i++){echo $tt[$i];usleep(50);}
    if($stt%$solan==0){
        echo $luc."Thành Công đã spam ".$trang.$stt.$luc." vào id ".$trang.$idsp."\n";
        echo $luc."Bạn muốn chạy tiếp không?(y/n): ".$vang;
        $hoi=readline();
        if($hoi=="y" or $hoi=="Y"){
        } else {
            echo $luc."Cảm ơn bạn đã dùng tool TĐK. \n";
            break;
        }
    }
    delay($delay);
    
}
/************Function*************/
function dvfb($loai,$id,$noidung,$cookie){
    $url='https://'.$_SESSION['API'].'/api/?loai='.$loai.'&id='.$id.'&noidung='.urlencode($noidung).'&cookie='.urlencode($cookie);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'authority: '.$_SESSION['API'],
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language: vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control: max-age=0',
        'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'sec-fetch-dest: document',
        'sec-fetch-mode: navigate',
        'sec-fetch-site: none',
        'sec-fetch-user: ?1',
        'upgrade-insecure-requests: 1',
        'user-agent: TOOL TĐK',
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}
function delay($delay)
{
    for($tt = $delay ;$tt> -1;$tt--){
        echo "\r\033[1;33m   Trần Đăng Khoa \033[1;31m =>       \033[1;32m LO      \033[1;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;31m    Trần Đăng Khoa \033[0;33m   =>     \033[0;37m LOA     \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;32m    Trần Đăng Khoa \033[0;33m    =>   \033[0;37m LOAD    \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;34m    Trần Đăng Khoa \033[0;33m     => \033[0;37m LOADI   \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m      =>\033[0;37m LOADIN  \033[0;31m | $tt | ";
        usleep(140000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m       =>\033[0;37m LOADING \033[0;31m | $tt | ";
        usleep(145000);
        echo "\r\033[1;35m    Trần Đăng Khoa \033[0;33m        =>\033[0;37m LOADING\033[0;31m | $tt | ";
        usleep(14500);
        echo "\r\e[1;95m    Trần Đăng Khoa                                  \r";
    }
}