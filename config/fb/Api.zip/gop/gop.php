<?php
header('Content-Type: text/html; charset=utf-8');
$userAgent = $_SERVER['HTTP_USER_AGENT'];
if($userAgent!='TOOL TĐK'){
    require_once ($_SERVER['DOCUMENT_ROOT'].'/404.php');
    die;
}
?>
#TOOL TĐK
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
//error_reporting(0);
/***[ Color ]***/
$nau= "\e[38;5;94m";
$xnhac = "\033[1;36m";
$do = "\033[1;31m";
$luc = "\033[1;32m";
$vang = "\033[1;33m";
$xduong = "\033[1;34m";
$hong = "\033[1;35m";
$trang = "\033[1;37m";
/***[ USERAGENT ]***/
$_SESSION['useragent'] = 'Mozilla/5.0 (Linux; Android 10; CPH1819) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36';
$res="\033[0m";
$BBlack="\033[1;30m" ; 
$BRed="\033[1;31m" ;
$Bmg="\033[1;32m" ;
$BYellow="\033[1;33m" ;
$BBlue="\033[1;34m" ;
$BPurple="\033[1;35m" ;
$BCyan="\033[1;36m" ;
$BWhite="\033[1;37m" ;
$Blue="\033[0;34m";
$lmg="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$mtool="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$red="\033[1;31m";
$white= "\033[1;37m";
$whiteb= "\033[1;37m";
$pmtol="\033[1;31m";
$green="\033[1;32m";
$yellow="\033[1;33m";
$cam="\033[1;33m";
$test="\033[1;33m";
$greenb="\033[1;32m";
$blue="\033[1;34m";
$lam="\033[1;34m";
$tmi="\033[1;34m";
$hong="\033[1;35m";
$imt="\033[1;35m";
$cyan= "\e[1;36m";
$syan="\033[1;36m";
$xnhac= "\033[1;96m";
$den="\033[1;90m";
$do="\033[1;91m";
$luc="\033[1;92m";
$vang="\033[1;93m";
$xduong="\033[1;94m";
$hong="\033[1;95m";
$trang="\033[1;97m";
$vang="\033[1;93m";
$do="\033[1;91m";
$BBlack="\033[1;30m";      
$BRed="\033[1;31m";
$BGreen="\033[1;32m";
$BYellow="\033[1;33m";
$BBlue="\033[1;34m";
$BPurple="\033[1;35m";
$BCyan="\033[1;36m";
$BWhite="\033[1;37m";
$Blue="\033[0;34m";
$lime="\033[1;32m";
$red="\033[1;31m";
$xanh="\033[1;32m";
$cyan="\033[1;36m";
$yellow="\033[1;33m";
$turquoise="\033[1;34m";
$maugi="\033[1;35m";
$white= "\033[1;37m";
$BCyan="\033[1;36m";
$trang="\033[1;37m";
$do="\033[1;31m";
$luc="\033[1;32m";
$vang="\033[1;33m";
$luc="\033[1;92m";
$ngblack="\033[40m"; 
$maufulldo= "\e[1;47;31m"; 
$ress="\033[0;32m";
$maufulldo= "\e[1;47;31m";
$res="\033[0m";
$red="\033[1;31m";
$green="\033[1;92m";
$yellow="\033[1;93m";
$white= "\033[1;97m";  
$banner="\r";
$xnhac= "\033[1;96m";
$den="\033[1;90m";
$do="\033[1;91m";
$luc="\033[1;92m";
$vang="\033[1;93m";
$xduong="\033[1;94m";
$hong="\033[1;95m";
$trang="\033[1;97m";
$ngay = date("d-m-Y"); 
$cuongdz = $do."[".$luc."•".$do."] ".$trang."=> ";
$cuongvip = $do."[".$luc."•".$do."]";
$thanhngang = $trang."----------------------------------------------------------\n";
date_default_timezone_set("Asia/Ho_Chi_Minh");
$useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36";
$wait = $green."Đợi";
$ress = "\033[0;32m";
$res = "\033[0;33m";
$red = "\033[0;31m";
$green = "\033[0;37m";
$yellow = "\033[0;33m";
$white = "\033[1;37m";
$xnhac = "\033[1;96m";
$den = "\033[1;90m";
$do = "\033[1;91m";
$luc = "\033[1;92m";
$vang = "\033[1;93m";
$xduong = "\033[1;94m";
$hong = "\033[1;95m";
$trang = "\033[1;97m";
$do="\033[1;91m";
$maufulldo= "\e[1;47;31m";
$res="\033[0m";
$red="\e[1;31m";
$pink="\e[1;35m";
$green="\e[1;32m";
$yellow="\e[1;33m";
$y2="\033[0;33m";
$cyan= "\e[1;36m";
$blue="\e[1;34m";
$ngreen="\033[42m";
$ngblack="\033[40m";
$nen="\033[1;47;1;34m";
$_SESSION['moi']=$trang."(".$vang."Mới".$trang.")";
$_SESSION['baotri']=$trang."(".$do."Bảo trì".$trang.")";
$_SESSION['sapra']=$trang."(".$do."Sắp Ra mắt".$trang.")";
@system('clear');
/***[ Banner ]***/
$_SESSION['urlsever']="https://".$_SESSION['API']."/gop/";
$daucau= $do."[" . $trang . "●" . $do . "] ".$trang."=> ";
$thanhngang= $do."------------------------------------------------------------\n";
$thanh_thang_mau_trang = "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n";
	back:
@system('clear');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, liken Gecko) Chrome/84.0.4147.135 Safari/537.36";
banner();
echo $daucau.$luc."Link Key 1: ".$vang.$linkkey1."\n";
echo $daucau.$luc."Link Key 2: ".$vang.$linkkey2."\n";
echo $daucau.$luc."Thời Gian: ".$vang.$songay."\n";
echo $daucau.$luc."Bắt Đầu: ".$vang.$thoigiantao."\n";
echo $daucau.$luc."Kết Thúc: ".$vang.$thoigianhet."\n";
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";usleep(50000);
echo "\033[1;32m║"; echo "\033[1;36m  Tool Trao Đổi Sub";echo "\033[1;32m  ║\n";usleep(50000);
echo "\033[1;32m╚═════════════════════╝\n";usleep(50000);
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."1.1".$do."] ".$luc."Tool Auto Trao Đổi Sub Đa Cookie".$_SESSION['moi']." \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."1.2".$do."] ".$luc."Tool Auto Trao Đổi Sub Pro5".$_SESSION['moi']." \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."1.3".$do."] ".$luc."Tool Auto Trao Đổi Sub TikTok\n";
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";usleep(50000);
echo "\033[1;32m║"; echo "\033[1;36m Tool Tương Tác Chéo";echo "\033[1;32m ║\n";usleep(50000);
echo "\033[1;32m╚═════════════════════╝\n";usleep(50000);
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."2.1".$do."] ".$luc."Tool Auto Tương Tác Chéo Đa Cookie".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."2.2".$do."] ".$luc."Tool Auto Tương Tác Chéo Tik Tok  \n";
echo "\033[1;33m"."------------------------------------------------------------\n";usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";usleep(50000);
echo "\033[1;32m║"; echo "\033[1;36m Tool Instagram     ";echo "\033[1;32m ║\n";usleep(50000);
echo "\033[1;32m╚═════════════════════╝\n";usleep(50000);
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."3.1".$do."] ".$luc."Tool VipIG$vang (TTC)$trang(".$vang."Bảo Trì".$trang.")\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."3.2".$do."] ".$luc."Tool TopIG$vang (TDS)".$_SESSION['moi']."\n";
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";usleep(50000);
echo "\033[1;32m║"; echo "\033[1;36m Tiện Ích Facebook  ";echo "\033[1;32m ║\n";usleep(50000);
echo "\033[1;32m╚═════════════════════╝\n";usleep(50000);
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.1".$do."] ".$luc."Tool Nuôi Facebook".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.2".$do."] ".$luc."Tool Reg Page vị trí".$_SESSION['moi']." \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.3".$do."] ".$luc."Tool Reg + Chuyển Page Chính".$_SESSION['moi']." \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.4".$do."] ".$luc."Tool Spam Cmt Id ".$_SESSION['sapra']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.5".$do."] ".$luc."Tool Spam Messages".$_SESSION['moi']." \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.6".$do."] ".$luc."Tool Thêm Bạn Bè \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.7".$do."] ".$luc."Tool Chấp Nhận Lời Mời Kết Bạn \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.8".$do."] ".$luc."Tool Chọc Bạn Bè ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.9".$do."] ".$luc."Tool Spam SMS ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.11".$do."] ".$luc."Tool Reg Page Pro5 ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.12".$do."] ".$luc."Tool Thêm Bạn Bè Không Gợi Ý ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.13".$do."] ".$luc."Tool Share Ảo ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.14".$do."] ".$luc."Tool Share Ảo Page Pro5 ".$_SESSION['moi']."\n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."4.15".$do."] ".$luc."Tool Follow Page Pro5 ".$_SESSION['moi']."\n";
echo "\033[1;33m"."------------------------------------------------------------\n";usleep(50000);
echo "\033[1;32m╔═════════════════════╗\n";usleep(50000);
echo "\033[1;32m║"; echo "\033[1;36m Liên Hệ Admin     ";echo "\033[1;32m  ║\n";usleep(50000);
echo "\033[1;32m╚═════════════════════╝\n";usleep(50000);
echo "\033[1;33m"."------------------------------------------------------------\n"; usleep(50000);
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."5.1".$do."] ".$luc."Facebook Admin \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."5.2".$do."] ".$luc."Zalo Admin \n";
echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Nhập ".$do."[".$vang."5.3".$do."] ".$luc."YouTube Admin \n";
echo "\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -\n";
while (true){
        echo $do."[".$luc."●".$do."] ".$trang."=> ".$luc."Vui Lòng Nhập Chế Độ: $vang";
        $chedo = trim(fgets(STDIN));
        if (!$sock = @fsockopen("www.google.com", 80)) {
                echo 'Vui lòng kết nối mạng !! ';
                exit();
        }
        /*****[ Trao Đổi Sub ]*****/
        if ($chedo == '1.1'){
                eval(get($_SESSION['urlsever']."tdsfb.php"));break;}
        if ($chedo == '1.2'){
                eval(get($_SESSION['urlsever']."tdspro5.php"));break;}
        if ($chedo == '1.3'){
                eval(get($_SESSION['urlsever']."tdstiktok.php"));break;}
        /*****[ Tương Tác Chéo ]*****/
        if ($chedo == '2.1'){
                eval(get($_SESSION['urlsever']."ttcfb.php"));break;}
        if ($chedo == '2.2'){
                eval(get($_SESSION['urlsever']."ttctiktok.php"));break;}
        /*****[ INSTAGRAM ]*****/
        if ($chedo == '3.1'){
                echo $do."Hệ Thông VIPIG Đang Bảo Trì! \n";continue;}
        if ($chedo == '3.2'){
                eval(get($_SESSION['urlsever']."topig.php"));break;}
        /*****[ Tiện Ích  ]*****/
        if ($chedo == '4.1'){
                eval(get($_SESSION['urlsever']."nuoifb.php"));break;}
        if ($chedo == '4.2'){
                eval(get($_SESSION['urlsever']."regvitri.php"));break;}
        if ($chedo == '4.3'){
                eval(get($_SESSION['urlsever']."regchuyenpage.php"));break;}
        if ($chedo == '4.4'){
                echo "Hệ thống sắp ra mắt bạn có thể vào lại sau\n";continue;}
        if ($chedo == '4.5'){
                eval(get($_SESSION['urlsever']."spammess.php"));break;}
        if ($chedo == '4.6'){
                eval(get($_SESSION['urlsever']."thembanbe.php"));break;}
        if ($chedo == '4.7'){
                eval(get($_SESSION['urlsever']."chapnhan.php"));break;}
        if ($chedo == '4.8'){
                eval(get($_SESSION['urlsever']."chocbanbe.php"));break;}
        if ($chedo == '4.9'){
                eval(get($_SESSION['urlsever']."spamsms.php"));break;}
        if ($chedo == '4.11'){
                eval(get($_SESSION['urlsever']."regpro5.php"));break;}
        if ($chedo == '4.12'){
                eval(get($_SESSION['urlsever']."addkhonggoiy.php"));break;}
        if ($chedo == '4.13'){
                eval(get($_SESSION['urlsever']."shareao.php"));break;}
        if ($chedo == '4.14'){
                eval(get($_SESSION['urlsever']."shareaopage.php"));break;}
        if ($chedo == '4.15'){
                eval(get($_SESSION['urlsever']."followpage.php"));break;}
        if ($chedo == '5.1'){
                echo"Đang Chuyển Hướng Tới Facebook Admin \n";
                $urladmin="https://www.facebook.com/khoatran31122006";
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
                        @system('xdg-open ' . $urladmin);
                } else {
                        @system('cmd /c start ' . $urladmin);
                }
                continue;
        }
        if ($chedo == '5.2'){
                echo"Đang Chuyển Hướng Tới Zalo Admin \n";
                $urladmin="https://zalo.me/0564903363";
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
                        @system('xdg-open ' . $urladmin);
                } else {
                        @system('cmd /c start ' . $urladmin);
                }
                continue;
        }
        if ($chedo == '5.3'){
                echo"Đang Chuyển Hướng Tới YouTube Admin \n";
                $urladmin="https://youtube.com/@TranDangKhoa206";
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
                        @system('xdg-open ' . $urladmin);
                } else {
                        @system('cmd /c start ' . $urladmin);
                }
                continue;
        }else{echo $do."Không Xác Định !!!\n";
        }
}
	function get($url){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers = array();
    $headers[] = 'User-Agent:TOOL TĐK';
    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers[] = 'Accept-Language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Vui lòng kiểm tra lại kết nối hoặc có thể do lỗi máy chủ!';
    }
    curl_close($ch);
    return $result;
    }